<?php
/**
 *
 * 
 * $Author: BoxCore $
 * $Id:
 */


/**
 * 功能描述：
 *
 * @param   int $num
 * @param   int $start
 * @access  private
 * @return  array
 */

