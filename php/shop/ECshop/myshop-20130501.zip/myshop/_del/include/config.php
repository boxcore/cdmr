<?php
	include("init.php");
	$sql="select * from config";
	$rows=mysql_query($sql);
	while($row=mysql_fetch_assoc($rows)){
		define($row["defname"],"{$row['value']}");
	}

