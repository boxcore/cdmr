<?php
session_start();
header("content-type:text/html;charset=utf8");
include("../../include/init.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>commit</title>
	</head>
	<body>

		<div id="head">
<?php include("../public/head.php") ?>

		</div>
		<h1>产品评论</h1>

		<table border=1 >
			<tr>
				<th>产品id</th>
				<th>产品名称</th>
				<th>图片</th>
				
			</tr>
			<tr>
				<?php
					$pid=$_GET["pid"];
					$sql="select * from goods where id={$pid}";
					$rows=mysql_query($sql);
					$row=mysql_fetch_assoc($rows);
					echo "<td>{$pid}</td>";
					echo "<td>{$row['name']}</td>";
					echo "<td><img src='../../images/{$row["pic"]}' /></td>";
				

				?>
			</tr>

		</table>
<form method=post action=insert.php>
				<textarea cols="40" rows="4" name="content" ></textarea>
				<br/>
				<input type=hidden name="pid" value="<?php echo "{$pid}" ?>"/>
				<input type=submit value="提交" />
			</form>
		<hr>
		<center>


			<table width=700 border=1>
	<tr>
		<th>id</th>
		<th>评论内容</th>
		<th>评论者</th>
		<th>评论时间</th>
	</tr>

<?php

	$sql="select * from commit where pid={$pid}";
	$rows=mysql_query($sql);
$list=1;
while($row=mysql_fetch_assoc($rows)){
	echo "	<tr><td>{$list}</li>";
		echo "<td>{$row['content']}</td>";
		
		$sql2="select user.username from user where id={$row['uid']}";
		$rows2=mysql_query($sql2);
		$row2=mysql_fetch_assoc($rows2);
		echo "<td>{$row2['username']}</td>";



		echo "<td>".date("Y-m-d H:i:s",$row['time'])."</td></tr>";
	$list++;
}

?>

</table>


</center>
	</body>
</html>
