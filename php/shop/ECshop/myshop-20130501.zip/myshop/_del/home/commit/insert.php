<?php
session_start(); 
if($_SESSION['login']!=1){
	header("location:../user/login.php");
}
include("../../include/init.php");
header("content-type:text/html;charset=utf8");
$content=$_POST["content"];
$pid=$_POST['pid'];
$uid=$_SESSION["user_name"];
$uid=$_SESSION["user_id"];
$time=time();
$sql="insert into commit(uid,content,pid,time) values('{$uid}','{$content}','{$pid}','{$time}')";

if(mysql_query($sql)){
	echo "<script>location='index.php?pid={$pid}'</script>";
	}
