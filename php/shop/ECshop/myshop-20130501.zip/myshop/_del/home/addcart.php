<?php
/* 购物车模块：计算购物车和总价
 * @param  $_SESSION["shops"]=key(pid)=>{0=>pid,1=>名称,2=>图片,3=>单价,4=>库存,5=>产品的添加时间,6=>上下架情况,7=>品牌id,num=>数目}
 * 说明：根据提交过来的产品id$_SESSION["shops"]["$id"]中
 */	
    session_start();
	header("content-type:text/html;charset=utf8");
    include("../include/init.php");
    $id=$_GET['id'];
	$sql="select goods.id,goods.name,goods.pic,goods.price,goods.stock from goods where id={$id}";
    $rows=mysql_query($sql);
    $row=mysql_fetch_assoc($rows);
    if($_SESSION["shops"]["$id"]){
        $_SESSION["shops"]["$id"]["num"]++;
    }else{
        $_SESSION["shops"]["$id"]=$row;
        $_SESSION["shops"]["$id"]["num"]=1;
    }
    header("location:mycart.php");
?>

