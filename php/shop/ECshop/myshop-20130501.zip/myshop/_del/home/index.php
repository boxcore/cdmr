<?php
	session_start();
	include("../include/init.php");
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>DEMO-商城测试首页</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="head">
        <?php include("public/head.php") ?>
    </div>
    <div id="main">
        <p><b>浏览商品信息</b></p>
        <table border="1" cellspacing=0 width="800px">
            <tr>
                <th>商品编号</th>
                <th>商品分类</th>
                <th>商品名称</th>
                <th>商品图片</th>
                <th>商品单价</th>
                <th>库存量</th>
                <th>添加时间</th>
				<th>评论</th>
                <th>编辑</th>
                <th>删除</th>
                <th>放入购物车</th>
            </tr>
            <?php
                $sql="select * from goods order by id";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_assoc($rows)){
					if($row['cartup']){
                    $sql2="select * from brand where id={$row['bid']}";
                    $rows2=mysql_query($sql2);
					$row2=mysql_fetch_assoc($rows2);
                    echo "<tr>
						<td>{$row['id']}</td>
						<td>{$row2['bname']}</td>
						<td>{$row['name']}</td>
                        <td><a href='../images/".substr($row['pic'],4)."' target='_blank'><img src='../images/{$row['pic']}'></a></td>
						<td>{$row['price']}</td>
						<td>{$row['stock']}</td>
						<td>{$row['time']}</td>
						<td><a href='commit/index.php?pid={$row['id']}'>评论</a></td>
						<td><a href='edit.php?id={$row['id']}'>编辑</a></td>
                        <td><a href='del.php?id={$row['id']}'>删除</a></td>
                        <td><a href='addcart.php?id={$row['id']}'>放入购物车</a></td>
                    </tr>";
                    }
                }
            ?>
        </table>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
