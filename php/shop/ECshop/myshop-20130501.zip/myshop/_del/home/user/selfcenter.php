<?php
    session_start();
    include("../../include/init.php");
    if(!$_SESSION['login']){
        header("location:login.php"); 
    }
    $uid=$_SESSION['user_id'];
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php
            include("../public/head.php");
        ?>
    </div>
    <div id=div1>
        <p><b>查看订单</b></p>
        <table border="1">
           <tr>
               <th>收货人</th>
               <th>收货人电话</th>
               <th>收货人地址</th>
               <th>订单号</th>
               <th>商品数量</th>
               <th>商品总价格</th>
               <th>订单状态</th>
               <th>订单时间</th>
           </tr>
           <?php
                $sql="select * from ordertab order by id";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_assoc($rows)){
                    if($uid===$row['uid']){
                    $sql2="select * from user where id={$row['uid']}";
                    $rows2=mysql_query($sql2);
                    $row2=mysql_fetch_assoc($rows2);
                    echo "<tr>";
                        echo "<td>{$row2['realname']}</td>";
                        echo "<td>{$row2['tel']}</td>";
                        echo "<td>{$row2['addr']}</td>";
                        echo "<td>{$row['sn']}</td>";
                        //取商品名称
                        $goods=json_decode(urldecode($row['info']),true);
						
						
                        $tot=0;
                        $num=0;
                        foreach($goods as $shop){
                            $tot+=$shop['price']*$shop['num'];
                            $num+=$shop['num'];
                        }
                        echo "<td>$num</td>";
                        echo "<td>$tot</td>";
                        echo "<td>{$row['status']}</td>";
                        echo "<td>".date("Y-m-d H:i:s",$row['time'])."</td>";
                    echo "</tr>";
                    }
                }
           ?>
       </table>     
    </div>
    </center>
</body>
<script>
    
</script>
</html>

