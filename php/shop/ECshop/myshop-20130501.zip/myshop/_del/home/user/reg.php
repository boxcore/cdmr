<?php
	session_start();
	header("content-type:text/html;charset=utf8");
	if($_SESSION["login"]==1){
		echo "亲，你已经登录，请点击这里<a href='../index.php'>返回首页</a>";
		exit;
	}
?>
<!DOCTYPE html>
<html>
	<head>
		
		<title>reg page</title>
		<link />
	</head>
	<body>
		<h1>用户注册中心</h1>

		<form method=post action=insert.php>
			用户名：<input type=text name=username value='' />
			<br />
			密&nbsp;&nbsp;码:<input type=password name=password value='' />
			<br />
			地&nbsp;&nbsp;址: <input id="addr" name="addr" type="text" value="">
			<br />
			电&nbsp;&nbsp;话: <input id="tel" name="tel" type="text" value=""><br />
			邮&nbsp;&nbsp;箱: <input id="mail" name="mail" type="text" value="" /><br />
			中文全名: <input id="realname" name="realname" type="text" value=""><br />
			密保问题: <input id="question" name="question" type="text" value=""><br />
			密保答案: <input id="answer" name="answer" type="text" value=""><br />
			<input name="sub" type="submit" value="注册用户">&nbsp;<input name="reset" type="reset" value="重置" />
		</form>

		<hr />
		<h2>已经有帐号？直接在下面登录吧！</h2>
		<form id="fid" action="check.php" method="post">
           <p>用户名: <input id="userid" name="username" type="text" value=""></p>
           <p>密&nbsp;&nbsp;码: <input id="passid" name="password" type="password" value=""></p>
           <p><input name="sub" type="submit" value="登录"></p>
       </form>





	</body>
</html>

