<?php 
	session_start();

?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
	<?PHP
	echo "<pre>";
		print_r($_SESSION);
		echo "</pre>";
?>
	<center>
    <div id=div1>
        <p><b>用户登录</b></p>
       <form id="fid" action="check.php" method="post">
           <p>用户名: <input id="userid" name="username" type="text" value=""></p>
           <p>密&nbsp;&nbsp;码: <input id="passid" name="password" type="password" value=""></p>
           <p><input name="sub" type="submit" value="登录"></p>
       </form>     
    </div>
    </center>
</body>
<script>
    
</script>
</html>

