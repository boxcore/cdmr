<?php 

	session_start();
	$_SESSION=array();
	setcookie("PHPSSID","",time()-1,"");
	session_destroy();
	header("location:../index.php");



