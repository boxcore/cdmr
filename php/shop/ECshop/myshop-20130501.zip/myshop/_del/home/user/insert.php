<?php
session_start(); 
include("../../include/init.php");
header("content-type:text/html;charset=utf8");


    $id=$_POST['id'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $admin=$_POST['admin'];
    $addr=$_POST['addr'];
    $tel=$_POST['tel'];
	$mail=$_POST['mail'];
	$realname=$_POST['realname'];
	$question=$_POST['question'];
	$answer=$_POST['answer'];
    $sql="insert user (username,password,admin,addr,tel,mail,realname,question,answer) values ('{$username}','{$password}','{$admin}','{$addr}','{$tel}','{$mail}','{$realname}','{$question}','{$answer}')";
    if(mysql_query($sql)){
        header("location:../index.php"); 
	}
