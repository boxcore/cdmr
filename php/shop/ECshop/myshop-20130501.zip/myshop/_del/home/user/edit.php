<?php  
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
?>
<?php include("../../include/init.php") ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php
            $id=$_GET['id'];
            $sql="select * from user where id={$id}";
            $rows=mysql_query($sql);
            $row=mysql_fetch_assoc($rows);
        ?>    
    </div>
    <div id=div1>
        <form id="fid" action="update.php" method="post">
            <p>用户名: <input id="username" name="username" type="text" value="<?php echo $row["username"] ?>" /></p>
            <p>密码: <input id="password" name="password" type="password" value="<?php echo $row["password"] ?>"></p>
            <p>是否管理员：<input type="radio" name="admin" value="0" <?php if($row["admin"]==0){echo "checked";} ?> />普通会员 &nbsp; <input type="radio" name="admin" value="1" <?php if($row["admin"]==1){echo "checked";} ?> />管理员 &nbsp;</p>
            <p>地址:&nbsp;&nbsp; <input id="addr" name="addr" type="text" value="<?php echo $row["addr"] ?>"></p>
            <p>电话: <input id="tel" name="tel" type="text" value="<?php  echo $row["tel"]?>"></p>
            <p>邮箱: <input id="mail" name="mail" type="text" value="<?php  echo $row["mail"]?>"></p>
            <p>中文全名: <input id="realname" name="realname" type="text" value="<?php  echo $row["realname"]?>"></p>
            <p>密保问题: <input id="question" name="question" type="text" value="<?php  echo $row["question"]?>"></p>
            <p>密保答案: <input id="answer" name="answer" type="text" value="<?php  echo $row["answer"]?>"></p>
            <p><input id="input" type="hidden" name="id" value="<?php echo $row["id"]?>"></p>
            <p><input name="sub" type="submit" value="点击修改">&nbsp;<input name="reset" type="reset" value="重置" /></p>
        </form>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
