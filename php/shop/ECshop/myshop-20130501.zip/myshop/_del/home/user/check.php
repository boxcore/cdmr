<?php
    session_start();

    $username=$_POST['username'];
	$password=$_POST['password'];

	

    include("../../include/init.php");
	$sql="select * from user where username='{$username}' and password='{$password}'";
	$rows=mysql_query($sql);
	$row=mysql_fetch_assoc($rows);
    if(mysql_num_rows($rows)==1){
		$_SESSION["user_name"]=$username;
		$_SESSION["padmin"]=$row["admin"];
		$_SESSION["user_id"]=$row["id"];
        $_SESSION["login"]=1;
		echo "<script>location='../index.php'</script>";
    }else{
        echo "<script>location='../login.php'</script>";
    }

