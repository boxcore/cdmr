<?php 
    session_start();
    if(!$_SESSION['login']){
        header("location:user/login.php");         
    }
    include("../include/init.php");
    $uid=$_SESSION['user_id'];
    $sql="select * from user where id={$uid}";
    $rows=mysql_query($sql);
    $row=mysql_fetch_row($rows);
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php  include("public/head.php")?> 
    </div>
    <div id=div1>
        <p><b>确认收货人信息</b></p>
        <form action="shoplist.php" method="post">
        <table border="1" cellspacing=0>
            <tr>
                <td>收货人姓名:</td><td><input type="text" name="username" disabled="disabled" size=50 value="<?php echo $row[1]?>"></td>
            </tr>
            <tr>
                <td>详细地址:</td><td><input type="text" name="addr" size=50 value="<?php echo $row[4]?>"></td>
            </tr>
            <tr>
                <td>电&nbsp;&nbsp;&nbsp;&nbsp;话:</td><td><input type="text" name="tel" size=50 value="<?php echo $row[5]?>"></td>
            </tr>
            <tr>
                <td>电子邮箱:</td><td><input type="text" size=50 name="mail" value="<?php echo $row[6]?>"></td>
            </tr>
            <tr>
                <td>真实姓名:</td><td><input type="text" size=50 name="realname" value="<?php echo $row[7]?>"></td>
            </tr>
            <tr>
                <td colspan=2 align="center"><input type="submit" value="查看购买清单"></td>
            </tr>
        </table>            
        <input type="hidden" name="id" value="<?php echo $row[0] ?>">
        </form>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
