<?php
    $username=$_SESSION['user_name'];
	$login=$_SESSION['login'];
	echo "<pre>";
	print_r($_SESSION);
	echo "</pre>";
?>
<h2 id="hid">demo商品前台功能测试<a href="/myshop/home/">访问测试首页</a></h2>
<?php
    if($login){
        echo "<span style='color:#f00'>{$username}</span> | ";
		if($_SESSION["padmin"]==1){
			echo "<a href='/myshop/admin/' target='_blank'>后台管理</a> | ";
		}
    }else{
        echo "<a href='/myshop/home/user/login.php'>登录</a> | ";
    }
?>
<a href="/myshop/home/user/logout.php">退出</a> |
<a href="/myshop/home/user/reg.php">注册用户</a> |
<a href="/myshop/home/index.php">浏览商品</a> |
<a href="/myshop/home/mycart.php">我的购物车</a> |
<a href="/myshop/home/clearcart.php">清空购物车</a> |
<a href="/myshop/home/user/selfcenter.php">个人中心</a> |
<a href="/myshop/home/order/index.php">查看订单</a>
<hr>
