<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php
            include("public/head.php");
            include("../include/init.php");
            $id=$_GET['id'];
            $sql="select * from shop where id={$id}";
            $rows=mysql_query($sql);
            $row=mysql_fetch_row($rows);
        ?>    
    </div>
    <div id=div1>
        <form id="fid" action="update.php" method="post" enctype="multipart/form-data">
            <p>商品名称: <input id="userid" name="name" type="text" value="<?php echo $row[1] ?>"></p>
            <p style='padding-left:60px'>商品图片: <input id="passid" name="pic" type="file" value="<?php echo $row[2] ?>"></p>
            <p>商品单价: <input id="passid" name="price" type="text" value="<?php echo $row[3]?>"></p>
            <p>库存量:&nbsp;&nbsp; <input id="passid" name="stock" type="text" value="<?php echo $row[4] ?>"></p>
            <p>添加时间: <input id="passid" name="password" type="text" value="<?php  echo $row[5]?>"></p>
            <p>商品分类: 
                <select name="classid" id="sid" style="margin-left:50px;">
                    <option value="default">--商品类别--</option>
                    <?php
                        $sql2="select * from shopclass order by id";
                        $rows2=mysql_query($sql2);
                        while($row2=mysql_fetch_row($rows2)){
                            if($row2[0]==$row[7]){
                                echo "<option selected='selected' value='{$row2[0]}'>{$row2[1]}</option>";
                            }else{
                                echo "<option value='{$row2[0]}'>{$row2[1]}</option>";
                            }
                        }
                    ?>
                 </select>
            </p>
            <p><input id="input" type="hidden" name="id" value="<?php echo $row[0]?>"></p>
            <p><input id="input" type="hidden" name="oldpic" value="<?php echo $row[2]?>"></p>
            <p><input name="sub" type="submit" value="点击修改"></p>
        </form>
        <img id="imgid" class="img" src="<?php echo 'images/'.$row[2]?>">
    </div>
    </center>
</body>
<script>
    
</script>
</html>
