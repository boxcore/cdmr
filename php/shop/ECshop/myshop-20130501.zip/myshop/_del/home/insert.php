<?php
    include("../include/init.php");
    include("../include/func.php");
    $name=$_POST['name'];
    $uppic=upload("pic");
    $pic=thumb($uppic,100,100);
    $price=$_POST['price'];
    $stock=$_POST['stock'];
    $time=time();
    $cid=$_POST['classid'];
    $sql="insert into goods(name,pic,price,stock,time,cid) values('{$name}','{$pic}','{$price}',$stock,$time,$cid)";
    if(mysql_query($sql)){
        header("location:index.php"); 
    }
