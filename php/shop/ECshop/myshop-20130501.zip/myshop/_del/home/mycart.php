<?php 
    session_start();
    include("../include/init.php"); 
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>

    <center>
    <div id="div">
        <?php include("public/head.php")?> 
    </div>
    <div id=div1>
       <p><b>我的购物车</b></p>
	   <?php 
		   

           if(!$_SESSION['shops']){
               echo "对不起，您的购物车为空!<br>"; 
               exit;
           }
	   ?>
       <table border="1" cellspacing=0 width="700px">
            <tr>
                <th>商品编号</th>
                <th>商品名称</th>
                <th>商品图片</th>
                <th>商品单价</th>
                <th>商品数量</th>
                <th>商品小计</th>
                <th>商品删除</th>
            </tr>
            <?php
		
                $tot=0;
                foreach($_SESSION['shops'] as $shop){
                    echo "<tr>
                        <td>{$shop['id']}</td>
                        <td>{$shop['name']}</td>
                        <td><img src='../images/{$shop['pic']}'</td>
                        <td>{$shop['price']}</td>   
                        <td><button onclick='location=\"count.php?act=reduce&id={$shop['id']}\"'>-</button> {$shop['num']} <button onclick='location=\"count.php?act=add&id={$shop['id']}\"'>+</button></td>
                        <td>".($shop['num']*$shop['price'])."</td>
                        <td><a href='count.php?act=del&id={$shop['id']}'>删除</a></td>
                    </tr>";
					//计算商品的总价
                    $tot+=$shop['num']*$shop['price'];
                }
				$_SESSION["amount"]=$tot;
				
                echo "<tr>
                     <td colspan='5'><b>价格总计</b></td>
                     <td colspan='2'>{$tot}</td>
                </tr>";
				
            ?>
       </table>     
    </div>
    <hr>
    <div id="div">
        <h2 id="hid" style="color:green"><a href="center.php">结算中心</a></h2>
    </div>
    </center>
</body>
</html>
