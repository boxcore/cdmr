<?php
    session_start();
    unset($_SESSION['shops']);
	unset($_SESSION['amount']); //把订单的总价清空
    //session_unset();
    //setcookie("PHPSESSID","",0,"/");
    //session_destroy();
    header("location:mycart.php");
