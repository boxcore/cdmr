<?php
session_start();
include("../include/init.php");
header("content-type:text/html;charset=utf8");
if(!$_SESSION['login']){
    header("location:user/login.php");
}

$uid=$_SESSION['uid'];
$num=time().mt_rand();
$info=json_encode($_SESSION['shops']);
$time=time();

$sql="insert into order(uid,num,info,time) values($uid,'$num','$info',$time)";
if(mysql_query($sql)){
    header("location:order/index.php");
}
?>
