<?php
    include("../include/init.php");
	header("content-type:text/html;charset=utf8");
    $id=$_GET['id'];
    $action=$_GET['action'];
    switch($action){
        case "up":
            $sql="update shop set cartup=1 where id={$id}";
            if(mysql_query($sql)){
                header("location:index.php"); 
                }
            break;
        case "down":
            $sql="update shop set cartup=0 where id={$id}";
            if(mysql_query($sql)){
                header("location:index.php"); 
                }
            break;
    }
