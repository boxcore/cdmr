<?php
    include('../include/init.php');
    $id=$_GET['id'];

    $sql="select * from goods where id={$id}";
    $rows=mysql_query($sql);
    $row=mysql_fetch_row($rows);
    if(mysql_num_rows($rows)>0){
        @unlink("images/".$row[2]);
        @unlink("images/".substr($row[2],4));

        $sql="delete from shop where id={$id}";
        if(mysql_query($sql)){
            header("location:index.php");
        }
    }

