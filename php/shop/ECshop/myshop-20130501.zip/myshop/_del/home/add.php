<?php
    session_start();
    if(!$_SESSION['login'] or !$_SESSION['admin']){
        header("location:user/login.php"); 
    }
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php
            include("public/head.php");
            include("include/init.php");
        ?>    
    </div>
    <div id=div1>
        <form id="fid" action="insert.php" method="post" enctype="multipart/form-data">
            <p>商品名称: <input id="userid" name="name" type="text" value=""></p>
            <p style="padding-left:60px">商品图片: <input id="passid" name="pic" type="file" value=""></p>
            <p>商品单价: <input id="passid" name="price" type="text" value=""></p>
            <p>库存量:&nbsp;&nbsp; <input id="passid" name="stock" type="text" value=""></p>
            <p>商品分类: 
                <select name="classid" id="sid" style="margin-left:50px;">
                    <option value="default">--商品类别--</option>
                    <?php
                        $sql="select * from shopclass order by id";
                        $rows=mysql_query($sql);
                        while($row=mysql_fetch_row($rows)){
                            echo "<option value='{$row[0]}'>{$row[1]}</option>";
                        }
                    ?>
                 </select>
            </p>
            <p><input id="input" type="hidden" name="id" value=""></p>
            <p><input name="sub" type="submit" value="点击添加"></p>
        </form>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
