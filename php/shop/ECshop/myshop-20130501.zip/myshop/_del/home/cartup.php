<?php
    session_start();
    if(!$_SESSION['login'] or !$_SESSION['admin']){
        header("location:user/login.php"); 
    }
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="head">
        <?php include("public/head.php") ?>
        <?php include("include/init.php") ?>
    </div>
    <div id="main">
        <p><b>浏览商品信息</b></p>
        <table border="1" cellspacing=0  width="700px">
            <tr>
                <th>商品编号</th>
                <th>商品名称</th>
                <th>商品图片</th>
                <th>上下架</th>
            </tr>
            <?php
                $sql="select * from shop order by id";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_row($rows)){
                    echo "<tr>
                        <td>$row[0]</td>
                        <td>$row[1]</td>
                        <td><img src='images/{$row[2]}'></td>";
                        if($row[6]){
                            echo "<td><a href='cartstat.php?action=down&id={$row[0]}'>下架</a></td>";
                        }else{
                            echo "<td><a href='cartstat.php?action=up&id={$row[0]}'>上架</a></td>";
                        }
                    echo "</tr>";
                }
            ?>
        </table>
    </div>
    </center>
</body>
<script>
    
</script>
</html>

