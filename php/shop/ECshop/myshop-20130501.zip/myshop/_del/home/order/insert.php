<?php
session_start();
include("../../include/init.php");
header("content-type:text/html;charset=utf8");
if(!$_SESSION['login']){
    header("location:../user/login.php");
}

$uid=$_SESSION['user_id'];
$sn=time().mt_rand();
$info=urlencode(json_encode((object)$_SESSION['shops']));
$time=time();
$amount=$_SESSION["amount"];

$sql="insert into ordertab(uid,sn,info,time,amount) values($uid,'$sn','$info',$time,$amount)";
if(mysql_query($sql)){
	unset($_SESSION['shops']); //把保存为订单的产品清单清空
	unset($_SESSION['amount']); //把订单的总价清空
    header("location:../user/selfcenter.php");
}

?>
