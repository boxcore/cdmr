<?php
    include("../../include/init.php");
    $id=$_POST['id'];
    $status=$_POST['status'];
    $sql="update ordertab set status='$status' where id={$id}";
    if(mysql_query($sql)){
        header("location:index.php"); 
    }
