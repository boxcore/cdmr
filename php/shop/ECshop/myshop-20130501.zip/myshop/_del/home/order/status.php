<?php
    include("../../include/init.php");
    $id=$_GET['id'];
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id="div">
        <?php include("../public/head.php"); 
            $id= $_GET['id'];
            $sql="select * from ordertab where id={$id}";
            $rows=mysql_query($sql);
			$row=mysql_fetch_assoc($rows);
        ?> 

    </div>
    <div id=div1>
        <p><b>订单状态修改</b></p>
        <form id="fid" action="update.php" method="post">
			<p>订单号: <input id="passid" name="order_id" disabled type="text" value="<?php echo $row["order_id"] ?>"></p>
			<p>订单状态: <input id="passid" name="status" type="text" value="<?php echo $row["status"] ?>"></p>
            <p><input id="input" type="hidden" name="id" value="<?php echo $id ?>"></p>
            <p><input name="sub" type="submit" value="submit"></p>
            <p style='color:red;font-weight:bold;'>*订单状态为: (未发货|已发货|已确认) 三种情况*</p>
        </form>      
    </div>
    </center>
</body>
<script>
    
</script>
</html>
