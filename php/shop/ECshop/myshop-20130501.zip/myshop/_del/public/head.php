<?php
    $username=$_SESSION['username'];
    $login=$_SESSION['login'];
?>
<h2 id="hid">商品信息管理</h2>
<?php
    if($login){
        echo "<span style='color:#f00'>{$username}</span> | ";
    }else{
        echo "<a href='/myshop/user/login.php'>登录</a> | ";
    }
?>
<a href="/myshop/user/logout.php">退出</a> |
<a href="/myshop/user/add.php">注册用户</a> |
<a href="/myshop/user/index.php">查看用户</a> |
<a href="/myshop/shopclass/add.php">添加商品分类</a> |
<a href="/myshop/shopclass/index.php">查看商品分类</a> |
<a href="/myshop/add.php">添加商品</a> |
<a href="/myshop/index.php">浏览商品</a> |
<a href="/myshop/mycart.php">我的购物车</a> |
<a href="/myshop/clearcart.php">清空购物车</a> |
<a href="/myshop/cartup.php">商品上下架</a> |
<a href="/myshop/user/selfcenter.php">个人中心</a> |
<a href="/myshop/order/index.php">查看订单</a>
<hr>
