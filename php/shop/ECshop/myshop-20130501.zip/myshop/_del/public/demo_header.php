<span class="myshopendheader"></span>
<script type="text/javascript" src="public/js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript" src="public/js/base-2011.js"></script>



<div id="shortcut">
  <div class="w">
    <ul class="fl lh">
      <li class="fore1 ld"><b></b><a href="javascript:add_to_favorite('http://www.xx.com/', 'xxx')">收藏京东网上商城</a></li>
    </ul>
    <ul class="fr lh">
      <li class="fore1 ld" id="loginbar" clstag="homepage|keycount|home2012|01e">
您好！欢迎来到京东网上商城！<a href="user.php">[登录]</a>&nbsp;<a href="user.php?act=register">[免费注册]</a>
</li>
      <li class="fore2" clstag="homepage|keycount|home2012|01f"><a href="user.php?act=order_list">我的订单</a></li>
      <li class="fore6 menu" data-widget="dropdown" clstag="homepage|keycount|home2012|01j">
        <dl>
          <dt class="ld"><a>客户服务<b></b></a></dt>
        </dl>
      </li>
    </ul>
    <span class="clr"></span> </div>
</div>
<div id="o-header">
<div class="w" id="header">
<div id="logo" class="ld"><a href="index.php"><b></b><img src="public/img/logo.gif" width="259" height="50"></a></div>
<div id="search">
<div class="i-search ld">
<b></b><s></s>
<ul id="shelper" class="hide">
</ul>
<div class="form">
<script type="text/javascript">
		
		<!--
		function checkSearchForm()
		{
			if(document.getElementById('key').value)
			{
				return true;
			}
			else
			{
				alert("请输入搜索关键词！");
				return false;
			}
		}
		-->
		
		</script>
<form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()">
<input type="text" class="text" accesskey="s" id="key"  name="keywords" autocomplete="off" onkeydown="javascript:if(event.keyCode==13) return checkSearchForm();"/>
<input type="submit" value="搜索" class="button" clstag="homepage|keycount|home2012|03a"/>
</form>
</div>
</div>
<script> (function(){
var B=["请输入商品关键字"];
B=pageConfig.FN_GetRandomData(B);$("#key").val(B).bind("focus",function(){if (this.value==B){this.value="";this.style.color="#333"}}).bind("blur",function(){if (!this.value){this.value=B;this.style.color="#999"}});
})();</script>
<div id="hotwords" clstag="homepage|keycount|home2012|03b"> <strong>热门搜索：</strong>  <a href="search.php?keywords=D-Link%E6%97%A0%E7%BA%BF%E8%B7%AF%E7%94%B1">D-Link无线路由</a>  <a href="search.php?keywords=%E4%BC%91%E9%97%B2%E7%94%B7%E9%9E%8B">休闲男鞋</a>  <a href="search.php?keywords=TCL%E7%A9%BA%E8%B0%83">TCL空调</a>  <a href="search.php?keywords=ELLE">ELLE</a>  </div>
</div>
<div id="my360buy" clstag="homepage|keycount|home2012|04a">
  <dl load='1'>
    <dt class="ld"><s></s><img src="themes/360buy/images/misc/lib/img/e/blank.gif" width="24" height="24" alt="头像"><a href="user.php">用户中心</a><b></b></dt>
    <dd>
	      <div class="prompt"> <span class="fl">您好，请登录</span> <span class="fr"><a class="btn-login" href="user.php">登录商城</a></span> </div>
	  

          </dd>
  </dl>
</div>
<div id="settleup" clstag="homepage|keycount|home2012|05a">
  <dl>
    <dt class="ld"> <s><span id="shopping-amount"></span></s> <a href="flow.php">去购物车结算</a> <b></b> </dt>
  </dl>
</div>
</div>
<div class="w">
  <div id="nav">
    <div id="categorys">
      <div class="mt ld">
        <h2><a href="catalog.php">全部商品分类<b></b></a></h2>
      </div>
    </div>
    <div id="treasure"></div>
    <ul id="navitems">
      <li class="fore1 curr" ><a href="index.php">首页</a></li>
            <li class="fore2"> <a  href="" >电脑频道</a> </li>
            <li class="fore2"> <a  href="" >家用电器</a> </li>
            <li class="fore2"> <a  href="" >品牌大全</a> </li>
            <li class="fore2"> <a  href="" >选购中心</a> </li>
            <li class="fore2"> <a  href="" >团购</a> </li>
            <li class="fore2"> <a  href="" >积分商城</a> </li>
            <li class="fore2"> <a  href="" >夺宝奇兵</a> </li>
            <li class="fore2"> <a  href="" >用户留言</a> </li>
          </ul>
  </div>
</div>
</div>
<span class="myshopendheader"></span>