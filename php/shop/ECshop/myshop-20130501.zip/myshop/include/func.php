<?php
    function code(){
        //开启session
        session_start();

        //1.准备画布
        $im=imagecreatetruecolor(104,25);

        //2.准备颜色
        $black=imagecolorallocate($im,0,0,0);
        $white=imagecolorallocate($im,255,255,255);
        $defcolor=imagecolorallocate($im,200,50,0);

        //3.画画或写字
        imagefill($im,0,0,$defcolor);

        //画干扰素-300左右点
        for($i=0;$i<300;$i++){
            $x=mt_rand(0,100);
            $y=mt_rand(0,50);
            imagesetpixel($im,$x,$y,$black);
        }

        //随机输出四个字-英文或数字
        $arr=array_merge(range(0,9),range("a","z"),range("A","Z"));
        shuffle($arr);
        $str=join(" ",array_slice($arr,0,4));

        //把str设置到session中
        $_SESSION['vcode']=$str;
        
        $dirpath=dirname(__FILE__);

        //把字放到画布上去
        imagettftext($im,20,0,5,20,$white,"{$dirpath}/simsun.ttc",$str);

        //4.输出或保存
        header("content-type:image/gif");

        //把图片保存起来
        imagegif($im);

        //5.关闭画布
        imagedestroy($im);
    }

    //图片上传
    function upload($pic){
        $error=$_FILES["$pic"]["error"];
        $name=$_FILES["$pic"]["name"];
        $tmp=$_FILES["$pic"]["tmp_name"];
        $ext=array_pop(explode('.',$name));
		$filename='../../images/'.time().mt_rand().'.'.$ext;

        if($error===0){
            //开始上传 
            if(move_uploaded_file($tmp,$filename)){
                return $filename;
            }
        }else{
            return false;
        }
    }


    //图片缩放
    function thumb($picname,$nw,$nh,$pre="thu_"){
        $info=getimagesize($picname);
        $w=$info[0];
        $h=$info[1];
        $type=$info[2];
        $mime=$info['mime'];

        //等比例缩放
        if(($nw/$w)>($nh/$h)){
            $b=$nh/$h;
        }else{
            $b=$nw/$w;
        }

        $nw=floor($b*$w);
        $nh=floor($b*$h);

        //创建画布
        switch($type){
            case 1:
                $im=imagecreatefromgif($picname);
                $im2=imagecreatetruecolor($nw,$nh);
                break;
            case 2:
                $im=imagecreatefromjpeg($picname);
                $im2=imagecreatetruecolor($nw,$nh);
                break;
            case 3:
                $im=imagecreatefrompng($picname);
                $im2=imagecreatetruecolor($nw,$nh);
                break;

        }

        //图片缩放
        if(!imagecopyresampled($im2,$im,0,0,0,0,$nw,$nh,$w,$h)){
           return false;      
        }

        //设置请求头类型
        //header("content-type:$mime");

        $path=pathinfo($picname);
        $savepath="{$path['dirname']}/{$pre}{$path['basename']}";

        //输出图片
        switch($type){
            case 1:
                imagegif($im2,$savepath);
                break;
            case 2:
                imagejpeg($im2,$savepath);
                break;
            case 3:
                imagepng($im2,$savepath);
                break;
        }

        //释放画布资源
        imagedestroy($im);
        imagedestroy($im2); 


        //返回值
        return basename($savepath);
    }
