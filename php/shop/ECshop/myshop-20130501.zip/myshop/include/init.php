<?php
//连接数据库
mysql_connect("localhost","test","123");
mysql_select_db("test_myshop");
mysql_query("set names utf8");

date_default_timezone_set("Asia/Shanghai");
$sql="select * from config";
$rows=mysql_query($sql);
while($row=mysql_fetch_assoc($rows)){
	define($row["defname"],"{$row['value']}");
}
header("content-type:text/html;charset=utf8");
?>
