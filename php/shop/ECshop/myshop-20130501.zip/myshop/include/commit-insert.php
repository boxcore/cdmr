<?php
session_start();
include("../include/init.php");

/*判断内容*/
$content=$_POST["content"];
if(!$_POST["content"]){
	echo "<script>alert('输入的内容不能为空，点确认返回');</script>";
	echo "<script>window.history.go(-1);</script>";
	exit;
}

/*验证码判断*/
$captcha=strtolower($_POST['captcha']);
$vcode=strtolower(str_replace(" ","",$_SESSION['vcode']));
if($captcha!=$vcode){
	echo "<script>alert('验证码错误，点确认返回');</script>";
	echo "<script>window.history.go(-1);</script>";
	exit;
}

$pid=$_POST['pid'];
$uid=$_SESSION["user_id"];
$mail=$_POST['mail'];
$time=time();
$sql="insert into commit(uid,mail,content,pid,time) values('{$uid}','{$mail}','{$content}','{$pid}','{$time}')";

if(mysql_query($sql)){
		echo "<script>alert('添加评论成功，点确认返回');</script>";
		echo "<script>location='../goods.php?id={$pid}#comment'</script>";

	}

