<?php
session_start();
include(dirname(__FILE__).'/init.php');
?>
