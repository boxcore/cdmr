<?php
session_start();
$id=$_GET['id'];
$action=$_GET['act'];
switch($action){
	//减少产品数量,设置最小值为1
    case 'reduce':
    if($_SESSION["shops"]["$id"]["num"]<=1){
        $_SESSION["shops"]["$id"]["num"]=1; 
    }else{
    $_SESSION["shops"]["$id"]["num"]--; 
	}
    echo "<script>history.go(-1);</script>";
    break;
    case 'add':
	//产品数量添加，设置最大值等于库存
	if($_SESSION["shops"]["$id"]["num"]<$_SESSION['shops']["$id"]['stock']){
		$_SESSION["shops"]["$id"]["num"]++;
		}else{
			$_SESSION["shops"]["$id"]["num"]=$_SESSION['shops']["$id"]['stock'];
		}
    //header("location:../flow.php?act=mycart");
	echo "<script>history.go(-1);</script>";
    break;
    case 'del':
    unset($_SESSION["shops"]["$id"]); 
    echo "<script>history.go(-1);</script>";
    break;
}
