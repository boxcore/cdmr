<?php
include("include/access.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf8" />
<title>index</title>
<link href="themes/style.css" type="text/css" rel="stylesheet" />
<link href="themes/css/index.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php include("themes/page_header.php"); ?>
<div class="clearfix clr blank"></div>
<div id="main" class="w mt10">
  <div class="right"> 
    <!-- 首页分类、新品、新闻公告 --> 
    <!-- 首页分类产品列表 -->
    <?php
	include("themes/common/theme.func.php");
	//取出分类下的产品
	$sql_c="select * from category";
	$rows_c=mysql_query($sql_c);
	while($row_c=mysql_fetch_assoc($rows_c)){
		listCatGoods($row_c['id']);
	}
	?>
  </div>
  <div class="left"> 
    <!-- 分类树 -->
    <?php include("themes/cat_tree.php"); ?>
  </div>
  
  <!-- 文章中心 --> 
</div>
<!-- -->
<div class='clr'></div>
<?php include("themes/page_footer.php"); ?>
</body>
</html>
