<?php
include("include/access.php");
//用户页面配置文件
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf8" />
		<title>reg</title>
		<link href="themes/style.css" type="text/css" rel="stylesheet" />
        <link href="themes/css/user.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
		<?php include("themes/page_header.php"); ?>

<?php
$_GET["act"]?$_GET["act"]:($_GET["act"]="login");

/*
 * 登陆页面
 *
 */
if($_GET["act"]=="login"){
	if($_SESSION["login"]==1){
	echo "<script>location='user_area.php?act=main'</script>";
	}
	include("themes/user_login.php");
}

/*
 * 用户注册页面
 *
 */
elseif($_GET["act"]=="register"){
	include("themes/user_register.php");
}

/*
 * 退出登陆
 *
 */
elseif($_GET["act"]=="logout"){
	$_SESSION=array();
	setcookie("PHPSSID","",time()-1,"");
	session_destroy();
	echo "<script>location='index.php'</script>";
}


/*
 * 用户的查询和删除
 *
 */
 
// 查询用户 是否存在
elseif($_GET["act"]=="check"){
	
	//判断用户名
	if(!$_POST['username'] || !$_POST['password']){
		echo "<script>alert('用户名和密码不能为空，点确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}
	
	/*验证码判断*/
	$captcha=strtolower($_POST['captcha']);
	$vcode=strtolower(str_replace(" ","",$_SESSION['vcode']));
	if($captcha!=$vcode){
		echo "<script>alert('验证码错误，点确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}

	$sql="select * from user where username='{$_POST['username']}' and password='{$_POST['password']}'";
    if($row=mysql_fetch_assoc(mysql_query($sql))){
		$_SESSION["user_name"]=$username;
		//$_SESSION["padmin"]=$row["admin"];
		$_SESSION["user_id"]=$row["id"];
        $_SESSION["login"]=1;
		$_SESSION["user_mail"]=$row["mail"];
		echo "<script>location='index.php'</script>";
    }else{
		echo "<script>alert('密码错误，点确认返回');</script>";
        echo "<script>location='user.php?act=login'</script>";
    }
}


// 增加用户
elseif($_GET["act"]=="add"){
	
	//判断用户名
	if(!$_POST['username'] || !$_POST['password']){
		echo "<script>alert('用户名和密码不能为空，点确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}
	
	/*验证码判断*/
	$captcha=strtolower($_POST['captcha']);
	$vcode=strtolower(str_replace(" ","",$_SESSION['vcode']));
	if($captcha!=$vcode){
		echo "<script>alert('验证码错误，点确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}
    $username=$_POST['username'];
    $password=$_POST['password'];
    $addr=$_POST['addr'];
    $tel=$_POST['tel'];
	$mail=$_POST['mail'];
	$realname=$_POST['realname'];
	$question=$_POST['question'];
	$answer=$_POST['answer'];
    $sql="insert user (username,password,addr,tel,mail,realname,question,answer) values ('{$username}','{$password}','{$addr}','{$tel}','{$mail}','{$realname}','{$question}','{$answer}')";
    if(mysql_query($sql)){
		$sql="select * from user where username='{$username}'";
    	$row=mysql_fetch_assoc(mysql_query($sql));
		$_SESSION["user_name"]=$username;
		$_SESSION["user_id"]=$row["id"];
        $_SESSION["login"]=1;
		$_SESSION["user_mail"]=$row["mail"];
		echo "<script>alert('注册成功，点确认返回首页');</script>";
		echo "<script>location='index.php'</script>";
	}


}
?>
		<?php include("themes/page_footer.php"); ?>
	</body>
</html>



