<?php
include("include/access.php");
include("themes/common/theme.func.php");
if($_SESSION["login"]!=1){
	header("location:user.php?act=login");
}
//从session中取当前用户相关的信息
$user_name=$_SESSION["user_name"];
$user_id=$_SESSION["user_id"];

//获取用户的相关信息 array $row_u
$sql_u="select * from user where id={$user_id}";
$row_u=mysql_fetch_assoc(mysql_query($sql_u));


//给与页面初始变量

//分类页地址，分页时调用
$page_name="user_area.php";
//$base_uri="user.php?id=$cat_id";
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf8" />
		<title>用户中心</title>
		<link href="themes/style.css" type="text/css" rel="stylesheet" />
		<link href="themes/css/user_area.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
<?php include("themes/page_header.php"); ?>
<div class="clearfix clr blank"></div>

<!-- 当前位置 -->
<div class="w mt10">
  <div class="cat-bread">
    <?php include("themes/ur_here.php"); ?>
  </div>
</div>


<div id="main" class="w mt10">
	<div class="right">
<?php

$_GET["act"]?$_GET["act"]:$_GET["act"]="main";

if($_GET["act"]=="main"){
	include("themes/user_area_main.php");
}
elseif($_GET["act"]=="info"){
	include("themes/user_area_info.php");
}
elseif($_GET["act"]=="order"){
	include("themes/user_area_order.php");
}
elseif($_GET["act"]=="order_list"){
	include("themes/user_area_order_list.php");
}
elseif($_GET["act"]=="addr"){
	include("themes/user_area_addr.php");
}
elseif($_GET["act"]=="commit"){
	include("themes/user_area_commit.php");
}
elseif($_GET["act"]=="cash"){
	include("themes/user_area_cash.php");
}


//修改用户基础信息
elseif($_GET["act"]=="baseinfo"){

	$mail=$_POST["mail"];
	$realname=$_POST["realname"];
	$tel=$_POST["tel"];
	$addr=$_POST["addr"];
	$sql="update user set mail='{$mail}',realname='{$realname}',tel='{$tel}',addr='{$addr}' where id='{$user_id}'";
	if(mysql_query($sql)){
		echo "<script>alert('修改成功，点确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
	}
}

//修改密码
elseif($_GET["act"]=="pass"){
	
	if(!$_POST["new_password"]||!$_POST["comfirm_password"]){
		echo "<script>alert('密码不能为空，请重新输入');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}

	if($_POST["new_password"]!=$_POST["comfirm_password"]){
		echo "<script>alert('两次输入密码不一致，请重新输入');</script>";
		echo "<script>window.history.go(-1);</script>";
		exit;
	}
	if($_POST["old_password"]==$row_u['password']){
		$sql="update user set password='{$_POST['new_password']}' where id='{$user_id}'";
		if(mysql_query($sql)){
		echo "<script>alert('密码修改成功，请点击确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
		}
	}else{
		echo "<script>alert('密码错误，请点击确认返回');</script>";
		echo "<script>window.history.go(-1);</script>";
	}
}
?>
	</div>
	<div class="left">
		<!-- 分类树 -->
		<?php include("themes/user_center.php"); ?>
	</div>


<!-- 文章中心 -->
</div>
<!-- -->
<div class='clr'></div>
<?php include("themes/page_footer.php"); ?>
	</body>
</html>