<?php
	echo __FILE__;
	echo "<hr>";
	echo "<pre>";
		print_r($_SERVER);
		echo "</pre>";
	echo $_SERVER[REQUEST_URI];

	echo "<hr>";

	$str="%7B%228%22%3A%7B%22id%22%3A%228%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+212%22%2C%22pic%22%3A%22thu_13661967131920209119.jpg%22%2C%22price%22%3A%223100%22%2C%22stock%22%3A%2238%22%2C%22num%22%3A4%7D%2C%2210%22%3A%7B%22id%22%3A%2210%22%2C%22name%22%3A%22Nikon+%5Cu5c3c%5Cu5eb7+23%22%2C%22pic%22%3A%22thu_1366196825317636765.jpg%22%2C%22price%22%3A%228700%22%2C%22stock%22%3A%2278%22%2C%22num%22%3A1%7D%7D";

	echo urldecode($str);
	echo "<hr>";

	$str2=json_decode(urldecode($str),true);

	echo $str2;
