<?php
include("include/access.php");
include("themes/common/theme.func.php");
//获取商品页面的id 同时赋值给 $id
$id=$_GET['id'];

//查询出商品数据
$sql_g="select * from goods where id=$id";
$row_g=mysql_fetch_assoc(mysql_query($sql_g));
$name=$row_g['name'];
$brand_id=$row_g['bid'];

//取品牌信息
$sql_b="select * from brand where id=$brand_id";
$row_b=mysql_fetch_assoc(mysql_query($sql_b));
$brand_id=$row_b['id'];
$brand_name=$row_b['bname'];

//取分类信息
$sql_c="select * from category where id in(select cid from brand where id=$brand_id)";
$row_c=mysql_fetch_assoc(mysql_query($sql_c));
$cat_id=$row_c['id'];
$cat_name=$row_c['cname'];


//给与页面初始变量

//分类页地址，分页时调用
$page_name="goods.php";
$base_uri="goods.php?id=$brand_id";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf8" />
<title>brand</title>
<link href="themes/style.css" type="text/css" rel="stylesheet" />
<link href="themes/css/page.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php include("themes/page_header.php"); ?>
<div class="clearfix clr blank"></div>

<!-- 当前位置 -->
<div class="w mt10">
  <div class="cat-bread">
    <?php include("themes/ur_here.php"); ?>
  </div>
</div>
<div id="main" class="w mt10">
  <div class="right"> 
    <!-- 商品详情 -->
    
    <div id="name">
      <h1><?php echo $name ?></h1>
    </div>
    <!-- 图片 -->
    <div id='preview'>
  <div id="spec-n1"><a href="images/<?php echo substr($row_g['pic'],4)?>" target="_blank"><img src="images/<?php echo substr($row_g['pic'],4)?>" width="350" height="350"></a></div>
  
  <div id="spec-n5">
      <div class="control" id="spec-left"></div>
      <div class="control" id="spec-right"></div>
      <div id="spec-list">
        <ul class="list-h">
                    <li> <img src="images/<?php echo $row_g['pic']; ?>" width="50" height="50" style="border: 1px solid rgb(204, 204, 204); padding: 2px;"></li>
                  </ul>
      </div>
    </div>
  </div>
  
  <ul id="summary">
  	<li><span>商品编号：<?php echo $id ?></span></li>
    <li>
      <div class="fl">售<span style=" padding-left:24px"></span>价：<strong class="price" id="goods_shop_price">￥<?php echo $row_g['price'] ?></strong></div>
      <span id="promotion1"></span>
      
      <div class="clr"></div>
    </li>
    <li><span>商品品牌：<a href="brand.php?id=<?php echo $brand_id ?>"><?php echo $brand_name ?></a></span></li>
    <li><span>库存：<?php echo $row_g['stock'] ?></span></li>
    <li><span>加入时间：<?php echo date("Y-m-d",$row_g['time']) ?></span></li>
    <li class="clearfix"><span class="fl">商品评论：</span>
      <div class="fl" id="star573692">
        <div class="star sa5"></div>
        <a class="num-comment" href="#comment">(已有<font id="goods_comment_num"><?php goodsMC($id); ?></font>人评价)</a> </div>
    </li>
  </ul>
  
  <!-- buy -->
  <div class="m" id="choose">
      <!--  
    <dl class="amount">
      <dt>　我要买：</dt>
      <dd>
      <a class="reduce" onclick="setAmount.reduce('#pamount')" href="javascript:void(0)">-</a>
        <input type="text" value="1" id="pamount" onkeyup="setAmount.modify('#pamount')" name="number">
      <a class="add" onclick="setAmount.add('#pamount')" href="javascript:void(0)">+</a></dd>
    </dl>-->
    <div class="btns"><a class="btn-append" href="flow.php?act=add&id=<?php echo $id; ?>">添加到购物车</a>
      <div class="fl " id="fqPanel"></div>
      <!--<input type="button" class="btn-coll" onclick="javascript:collect(10)" value="加关注">-->
      <span class="clr"></span></div>
    </div>
  
  <div class="clr clearfix"></div>
  <!--  商品描述 -->
  <div id="detail" class="mb10">
  	<ul class="tab">
    	<li class="curr">商品详情<span></span></li>
    </ul>
    <div id="goodsdesc">
    <?php if($row_g['content']){echo $row_g['content'];}else{ echo "<center><h1>还没有描述，敬请期待吧！</h1></center>";} ?>
    </div>
  
  </div>
  <div id="goodscommit">
  <ul class="tab">
    	<li class="curr">商品评论<span></span></li>
    </ul>
  <?php include("themes/goods_commit.php"); ?>
  </div>
        
    
    
  </div>
  <div class="left"> 
    <!-- 分类树 -->
    <?php include("themes/cat_tree.php"); ?>
  </div>
  
  
  <!-- 文章中心 --> 
</div>
<!-- -->
<div class='clr'></div>
<?php include("themes/page_footer.php"); ?>
</body>
</html>
