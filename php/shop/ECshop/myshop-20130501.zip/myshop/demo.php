<?php
session_start();
include("include/access.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf8" />
		<title>Demo Page</title>
		<link href="public/css/home.css" type="text/css" rel="stylesheet" />
		<link href="public/css/base.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
<?php include('public/demo_header.php'); ?>






<?php include('public/demo_footer.php'); ?>
	</body>
</html>

