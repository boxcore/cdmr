<?php
include("include/access.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf8" />
		<title>index</title>
		<link href="themes/style.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
		<?php include("themes/page_header.php"); ?>




		<?php include("themes/page_footer.php"); ?>
	</body>
</html>



