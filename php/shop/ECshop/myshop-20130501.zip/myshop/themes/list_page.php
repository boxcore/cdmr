
<div id="turn-page" class="mt10 clearfix">
	<div class="pagin fr">
		<span><?php echo $page."/".$pagenum; ?>页&nbsp;</span>
		<a class='prev' href='<?php echo $base_uri; ?>&page=1&<?php echo $url; ?>'>首页<b></b></a>
		<a class='prev' href='<?php echo $base_uri; ?>&page=<?php echo $prev; ?>&<?php echo $url; ?>'>上一页<b></b></a>
		<a class='next' href='<?php echo $base_uri; ?>&page=<?php echo $next; ?>&<?php echo $url; ?>'>下一页<b></b></a>
		<a class='next' href='<?php echo $base_uri; ?>&page=<?php echo $pagenum; ?>&<?php echo $url; ?>'>末页<b></b></a>

		<!--
		未用上特效
		<span class="prev-disabled">上一页<b></b></span>
		<a  href=''>1</a>
		<a class='current'  href=''>2</a>
		<span class="next-disabled">下一页<b></b></span>
		-->
  </div>
</div>

