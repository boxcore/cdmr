<div class="blank"></div>
<form name="formLogin" action="user.php?act=check&" method="post">
    <div class="w" id="entry">
      <div class="mt">
        <h2>用户登录</h2>
        <b></b> </div>
      <div class="mc" style="padding-top:20px;">
        <div class="form">
          <div class="item"> <span class="label">用户名：</span>
            <div class="fl">
              <input type="text" id="username" name="username" class="text" tabindex="1" value="">
            </div>
          </div>
          <div class="item"> <span class="label">密码：</span>
            <div class="fl">
              <input type="password" id="password" name="password" class="text" tabindex="2">
            </div>
          </div>
		            <div class="item" id="o-authcode"> <span class="label">验证码：</span>
            <div class="fl">
              <input type="text" id="captcha" style="ime-mode:disabled" name="captcha" class="text text-1" tabindex="6">
              <label class="img"> <img src="captcha.php" alt="captcha" style="vertical-align: middle;cursor: pointer;" onclick="this.src='captcha.php?'+Math.random()" id="login_captcha"> </label>
            </div>
          </div>
		            <div class="item" id="autoentry"> <span class="label">&nbsp;</span>
          </div>
          <div class="item"> <span class="label">&nbsp;</span>
		  <input type="hidden" name="act" value="check">
            <input type="submit" name="submit" class="btn-img btn-entry" value="登录" tabindex="8">
          </div>
        </div>
        <!--[if !ie]>form end<![endif]-->
        <div id="guide">
          <h5>还不是商城用户？</h5>
          <div class="content">现在免费注册成为商城用户，便能立刻享受便宜又放心的购物乐趣。</div>
          <a href="user.php?act=register" class="btn-link btn-personal">注册新用户</a> </div>
        <!--[if !ie]>guide end<![endif]-->
        <span class="clr"></span> </div>
      <!--[if !ie]>mc end<![endif]-->
    </div>
    <!--[if !ie]>regist end<![endif]-->
  </form>
  <div class="blank"></div>