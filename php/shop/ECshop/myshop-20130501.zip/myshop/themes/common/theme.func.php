<?php


/* 
 * 取分类产品函数,可以指定调用的分类id和取出产品的数目
 *
 *	@param	int		$cid		分类ID号
 *	@param	int		$listNum	展示分类下产品最大数量，默认取8个产品
 *	@return	void
 */
function listCatGoods($cid,$listNum=8){
	//判断分类下是否查询出产品数据
	$sql_bt="select * from goods where bid in(select id from brand where cid={$cid}) limit 0,1";
	if(mysql_num_rows(mysql_query($sql_bt))){

		//取分类名称
		$sql_c="select * from category where id={$cid}";
		$row_c=mysql_fetch_assoc(mysql_query($sql_c));
		echo "
		<div class='cat_goods'>
			<div class='ct'>
				<h2>{$row_c['cname']}</h2>
				<div class='bd'>";
					//取分类下的品牌分类
					$sql_b="select * from brand where cid={$row_c['id']}";
					$rows_b=mysql_query($sql_b);
					while($row_b=mysql_fetch_assoc($rows_b)){
						echo "<a href='brand.php?id={$row_b['id']}'>{$row_b['bname']}</a> / ";
					}
				echo "
				</div>
				<div class='extra'></div>
			</div>
			<div class='cg'>
				<ul class='list'>";
						//取分类下产品的数据
						$sql_bl="select * from goods where bid in(select id from brand where cid={$cid}) order by id desc limit 0,{$listNum}";
						$rows_bl=mysql_query($sql_bl);
						while($row_bl=mysql_fetch_assoc($rows_bl)){
							echo "<li>";
							echo "<div class='p-img'><a target='_blank' href='goods.php?id={$row_bl['id']}'><img src='images/{$row_bl['pic']}' width='100' height='100'/></a></div>";
							echo "<div class='p-name'><a target='_blank' href='goods.php?id={$row_bl['id']}'>{$row_bl['name']}</a></div>";
							echo "<div class='p-price'>售价<strong>￥{$row_bl['price']}</strong></div>";
							echo "</li>";
						}
					echo "
				</ul>
			</div>
		</div><div class='clr'></div>";
	}
}



//产品获得评论总数
function goodsMC($gid){
	$sql_mc="select count(*) from commit where pid=$gid";
	$row_mc=mysql_fetch_row(mysql_query($sql_mc));
	$goods_mc=$row_mc[0];
	echo $goods_mc;
}
?>
