<div class="blank"></div>
<div class="w">
  <div id="service">
    <div style="display:none;"><a href=""></a></div>
    <dl class="fore1" clstag="homepage|keycount|home2012|33a">
      <dt><b></b><strong>购物指南</strong></dt>
      <dd>
        <div><a href="help.php?id=7" target="_blank">购物流程 </a></div>
        <div><a href="help.php?id=8" target="_blank">会员介绍 </a></div>
        <div><a href="help.php?id=9" target="_blank">团购/机票/充值/点卡 </a></div>
        <div><a href="help.php?id=10" target="_blank">常见问题 </a></div>
        <div><a href="help.php?id=11" target="_blank">大家电 </a></div>
        <div><a href="help.php?id=12" target="_blank">联系客服 </a></div>
      </dd>
    </dl>
    <dl class="fore2" clstag="homepage|keycount|home2012|33a">
      <dt><b></b><strong>配送方式</strong></dt>
      <dd>
        <div><a href="help.php?id=13" target="_blank">上门自提 </a></div>
        <div><a href="help.php?id=14" target="_blank">快递运输 </a></div>
        <div><a href="help.php?id=15" target="_blank">特快专递（EMS） </a></div>
        <div><a href="help.php?id=16" target="_blank">如何送礼 </a></div>
        <div><a href="help.php?id=17" target="_blank">海外购物 </a></div>
      </dd>
    </dl>
    <dl class="fore3" clstag="homepage|keycount|home2012|33a">
      <dt><b></b><strong>支付方式</strong></dt>
      <dd>
        <div><a href="help.php?id=18" target="_blank">货到付款 </a></div>
        <div><a href="help.php?id=19" target="_blank">在线支付 </a></div>
        <div><a href="help.php?id=20" target="_blank">分期付款 </a></div>
        <div><a href="help.php?id=21" target="_blank">邮局汇款 </a></div>
        <div><a href="help.php?id=22" target="_blank">公司转账 </a></div>
      </dd>
    </dl>
    <dl class="fore4" clstag="homepage|keycount|home2012|33a">
      <dt><b></b><strong>售后服务</strong></dt>
      <dd>
        <div><a href="help.php?id=23" target="_blank">退换货政策 </a></div>
        <div><a href="help.php?id=24" target="_blank">退换货流程 </a></div>
        <div><a href="help.php?id=25" target="_blank">价格保护 </a></div>
        <div><a href="help.php?id=26" target="_blank">退款说明 </a></div>
        <div><a href="help.php?id=27" target="_blank">返修/退换货 </a></div>
        <div><a href="help.php?id=28" target="_blank">退款申请 </a></div>
      </dd>
    </dl>
    <dl class="fore5" clstag="homepage|keycount|home2012|33a">
      <dt><b></b><strong>特色服务</strong></dt>
      <dd>
        <div><a href="help.php?id=29" target="_blank">夺宝岛 </a></div>
        <div><a href="help.php?id=30" target="_blank">DIY装机 </a></div>
        <div><a href="help.php?id=31" target="_blank">延保服务 </a></div>
        <div><a href="help.php?id=32" target="_blank">家电下乡 </a></div>
        <div><a href="help.php?id=33" target="_blank">京东礼品卡 </a></div>
        <div><a href="help.php?id=34" target="_blank">能效补贴 </a></div>
      </dd>
    </dl>
    <span class="clr"></span> </div>
</div>
<div class="w">
  <div id="footer">
    <div class="links"> <a href="#">关于我们</a>| <a href="#">联系我们</a>| <a href="#">人才招聘</a>| <a href="#">商家入驻</a>| <a href="#">千寻网</a>| <a href="#">奢侈品网</a>| <a href="#">广告服务</a>| <a href="#">移动终端</a>| <a href="#">友情链接</a>| <a href="#">销售联盟</a>| <a href="#">京东论坛</a> </div>
    <div class="copyright"> © 2005-2013 京东网上商城 版权所有，并保留所有权利。&nbsp;	  ICP备案证书号:<a href="http://www.miibeian.gov.cn/" target="_blank">京ICP证070359号</a> <br>
    </div>
    <div class="authentication"><a href="#" target="_blank"><img src="themes/images/footer-beian.gif" width="108" height="40" alt="经营性网站备案中心"></a> <a href="#" tabindex="-1" id="urlknet" target="_blank"><img name="seal" border="true" src="themes/images/footer-trust2.jpg" width="112" height="40"></a><a href="#" target="_blank"><img src="themes/images/footer-polic.jpg" width="108" height="40" alt="海淀网络警察"></a><a href="#" target="_blank"><img src="themes/images/footer-trust.png" width="112" height="40"></a></div>
  </div>
</div>
<div class="blank"></div>
