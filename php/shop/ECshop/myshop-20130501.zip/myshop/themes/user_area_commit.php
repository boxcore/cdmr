<div class="box">
     <div class="box_1">
      <div class="userCenterBox boxCenterList clearfix" style="_height:1%;">
         
                  
         
                  
         
                    <h5><span>我的评论</span></h5>
          <div class="blank"></div>
                    <div class="f_l">
          <b>
		  		  商品提问
		  		  : </b><font class="f4"></font>&nbsp;&nbsp;(2013-04-25 21:13:48)
          </div>
          <div class="f_r">
          <a href="user.php?act=del_cmt&amp;id=27" title="删除" onclick="if (!confirm('你确实要彻底删除这条留言吗？')) return false;" class="f6">删除</a>
          </div>
          <div class="msgBottomBorder">
          dcvdvfdvssdvdvdfddd<br>
                    <b>回复：</b><br>
          dsdsd                     </div>
                    <div class="f_l">
          <b>
		  		  商品提问
		  		  : </b><font class="f4"></font>&nbsp;&nbsp;(2013-04-25 21:13:59)
          </div>
          <div class="f_r">
          <a href="user.php?act=del_cmt&amp;id=28" title="删除" onclick="if (!confirm('你确实要彻底删除这条留言吗？')) return false;" class="f6">删除</a>
          </div>
          <div class="msgBottomBorder">
          efaefaefaefa<br>
                    <b>回复：</b><br>
          dvdvdvsssdsd                     </div>
                              
<form name="selectPageForm" action="/360buy/user.php" method="get">


 <div id="pager" class="pagebar">
  <span class="f_l f6" style="margin-right:10px;">总计 <b>2</b>  个记录</span>
      
      </div>


</form>
<script type="Text/Javascript" language="JavaScript">
<!--

function selectPage(sel)
{
  sel.form.submit();
}

//-->
</script>

                        
    
        
    
        
    
        <div class="blank5"></div>
   
      
         
    
  
      </div>
     </div>
    </div>