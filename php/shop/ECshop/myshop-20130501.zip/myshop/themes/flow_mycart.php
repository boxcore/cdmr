<center>
    <div id=div1 style="width:904px;height:100%;background-color:#AACDED;" class="mt10">
       <p style="padding:5px;" ><h1 class="mb10">我的购物车</h1></p>
       <div style="width:900px;height:90%;background-color:#fff;">
       <table border="1" cellspacing=0 width="900px">
            <tr>
                <th>商品编号</th>
                <th>商品图片</th>
                <th>商品名称</th>
                <th>商品单价</th>
                <th width="100">商品数量</th>
                <th>商品小计</th>
                <th>商品删除</th>
            </tr>
            <?php if($_SESSION['shops']){ ?>
            <?php
		
                $tot=0;
                foreach($_SESSION['shops'] as $shop){
                    echo "<tr>
                        <td>{$shop['id']}</td>
						<td><img src='images/{$shop['pic']}' width='50'></td>
                        <td><a href='goods.php?id={$shop['id']}' target='_blank'>{$shop['name']}</a></td>
                        <td>{$shop['price']}</td>   
                        <td align='center'><button onclick='location=\"include/flow-count.php?act=reduce&id={$shop['id']}\"'>-</button> {$shop['num']} <button onclick='location=\"include/flow-count.php?act=add&id={$shop['id']}\"'>+</button></td>
                        <td>".($shop['num']*$shop['price'])."</td>
                        <td><a href='include/flow-count.php?act=del&id={$shop['id']}'>删除</a></td>
                    </tr>";
					//计算商品的总价
                    $tot+=$shop['num']*$shop['price'];
                }
				$_SESSION["amount"]=$tot;
				
                echo "<tr>
                     <td colspan='5'><b>价格总计</b></td>
                     <td colspan='2'>{$tot}</td>
                </tr>";
				
            ?>
            <?php }else{ echo "<tr><td colspan='7' align='center'><h1>目前购物车为空，回首页买商品去把！</h1></td></tr>";} ?>
       </table>  
       </div>
       <div id="div">
     	   <h2 id="hid" style="color:green;padding:5px"><a href="flow.php?act=center"><button>结算中心</button></a></h2>
    	</div>   
    </div>
    <div class=""></div>
    
</center>