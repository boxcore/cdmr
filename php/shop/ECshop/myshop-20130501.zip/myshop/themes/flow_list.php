<?php
    $id=$_POST['id'];
    $addr=$_POST['addr'];
    $tel=$_POST['tel'];
    $mail=$_POST['mail'];
    $realname=$_POST['realname'];

    $sql="update user set addr='{$addr}',tel='{$tel}',mail='{$mail}',realname='{$realname}' where id={$id}";

    if(mysql_query($sql)){
        $sql="select * from user where id={$id}"; 
        $rows=mysql_query($sql);
        $row=mysql_fetch_assoc($rows);
    }
?>

    <center>
    <div id=div1>
        <p><b>收货人信息</b></p>
        <table border="1" width="500px">
            <tr>
                <td>姓名:</td><td><input type="" value="<?php echo $row["username"] ?>" size=50 disabled="disabled"></td>
            </tr>
            <tr>
                <td>地址:</td><td><input type="" value="<?php echo $row["addr"] ?>" size=50 disabled="disabled"></td>
            </tr>
            <tr>
                <td>电话:</td><td><input type="" value="<?php echo $row["tel"] ?>" size=50 disabled="disabled"></td>
            </tr>
            <tr>
                <td>邮箱:</td><td><input type="" value="<?php echo $row["mail"] ?>" size=50 disabled="disabled"></td>
            </tr>
            <tr>
                <td>真实姓名:</td><td><input type="" value="<?php echo $row["realname"] ?>" size=50 disabled="disabled"></td>
            </tr>
        </table>    
    </div>
    <hr width="40%"/>
    <div id="div">
        <p><b>商品价格结算</b></p>
        <table border="1" width="500px">
        <tr>
            <th>图片</th><th>商品名称</th><th>商品单价</th><th>商品个数</th><th>商品小计</th>
        </tr>
        <?php
            $tot=0;
            foreach($_SESSION['shops'] as $shop){
                echo "<tr>
				<td><img src='images/{$shop['pic']}' width='50'/></td>
                    <td>{$shop['name']}</td>
                    <td>{$shop['price']}</td>
                    <td>{$shop['num']}</td>
                    <td>".($shop['num']*$shop['price'])."</td>
                </tr>";
                $tot+=$shop['num']*$shop['price'];
            }
        ?>
        </table>
    </div>
    <hr width="40%">
    <div id="div">
        <table width="500px" border=1px>
            <tr>
                <td>付款方式</td>
                <td>货到付款</td>
            </tr>
            <tr>
                <td>
                    <h2 id="hid" style='color:red'>您应付款总额: <?php echo $tot?>元</h2>
                </td>
                <td><h2><a href="flow.php?act=insert"><button>确认提交订单</button></a></h2></td>
            </tr>
        </table>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
