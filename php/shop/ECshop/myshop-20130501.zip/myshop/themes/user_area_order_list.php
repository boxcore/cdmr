<?php

//查询订单信息
$id=$_GET['id'];
$sql="select * from ordertab where id={$id}";
$row=mysql_fetch_assoc(mysql_query($sql));

//查询下订单会员信息
$sql_user="select * from user where id={$row['uid']}"; 
$row_user=mysql_fetch_assoc(mysql_query($sql_user));
?>
<div id="topbar"><h5>订单详情</h5></div>

<div class="list-div" style="margin-bottom:5px">
<table width="100%"  cellspacing="1" border="1">
  <tr>
    <th colspan="4">基本信息</th>
  </tr>
  <tr>
    <td width="18%"><div align="right"><strong>订单号：</strong></div></td>
    <td width="34%"><?php echo $row['sn'] ?></td>
    <td width="15%"><div align="right"><strong>订单状态：</strong></div></td>
    <td><?php
				switch($row["status"]){
					case 0:
					echo "未发货";
					break;
					case 1:
					echo "已发货";
					break;
					case 2:
					echo "已完成";
					break;
				}
				?></td>
  </tr>
  <tr>
    <td><div align="right"><strong>购货人：</strong></div></td>
    <td><?php echo $row_user["username"] ?></td>
    <td><div align="right"><strong>下单时间：</strong></div></td>
	<td><?php echo date("Y-m-d H:i:s",$row['time']); ?></td>
  </tr>
  <tr>
    <td><div align="right"><strong>支付方式：</strong></div></td>
    <td>货到付款</td>
	<td><div align="right"><strong>配送方式：</strong></div></td>
    <td>运费到付</td>
  </tr>
  <tr>
    <td><div align="right"><strong>收货人：</strong></div></td>
    <td><?php echo $row_user["realname"] ?></td>
    <td><div align="right"><strong>电子邮件：</strong></div></td>
    <td><?php echo $row_user["mail"] ?></td>
  </tr>
  <tr>
    <td><div align="right"><strong>地址：</strong></div></td>
    <td><?php echo $row_user["addr"] ?></td>
    <td><div align="right"><strong>手机：</strong></div></td>
    <td><?php echo $row_user["tel"] ?></td>
  </tr>

</table>
</div>

<div class="list-div" style="margin-bottom: 5px">
<table width="100%" cellpadding="3" cellspacing="1" border="1">
  <tr>
    <th colspan="8" scope="col">商品信息</th>
    </tr>
  <tr>
    <td scope="col"><div align="center"><strong>ID</strong></div></td>
    <td scope="col"><div align="center"><strong>商品名称</strong></div></td>
    <td scope="col"><div align="center"><strong>图片</strong></div></td>
    <td scope="col"><div align="center"><strong>价格</strong></div></td>
    <td scope="col"><div align="center"><strong>数量</strong></div></td>
    <td scope="col"><div align="center"><strong>库存</strong></div></td>
    <td scope="col"><div align="center"><strong>小计</strong></div></td>
  </tr>
  
<?php
            $order_info=json_decode(urldecode($row["info"]),true);
			$tot=0;
			$num=0;
			
			foreach($order_info as $goods){
				//取商品库存信息
				$sql_g="select * from goods where id={$goods['id']}";
				$row_g=mysql_fetch_assoc(mysql_query($sql_g));
				echo "<tr>";
				echo "<td>{$goods['id']}</td>";
				echo "<td><a href='goods.php?id={$goods['id']}' target='_blank' >{$goods['name']}</a></td>";
				echo "<td align='center'><img src='images/{$goods['pic']}' height='65'/></td>";
				echo "<td align='right'>￥{$goods['price']}元</td>";
				echo "<td align='right'>{$goods['num']}</td>";
				echo "<td align='right'>{$row_g['stock']}</td>";				
				echo "<td align='right'>￥".$goods['num']*$goods['price']."元</td>";
				echo "</tr>";
				$tot+=$goods['price']*$goods['num'];
				$num+=$goods['num'];
			}
        ?>
    <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><div align="right"><strong>购买商品数量：</strong></div></td>
    <td><div align="right"><?php echo $num; ?></div></td>
    
    <td><div align="right"><strong>合计：</strong></div></td>
    <td><div align="right">￥<?php echo $tot; ?>元</div></td>
  </tr>
</table>
</div>


<div class="list-div" style="margin-bottom: 5px">
<table  cellspacing="0" border="1">
  <tr>
    <th colspan="6">操作信息</th>
  </tr>
  <tr>
    <td><div align="right"></div>
      <div align="right"><strong>当前可执行操作：</strong> </div></td>
    <td colspan="5"><?php
				switch($row["status"]){
					case 0:
					echo "等待生成订单";
					break;
					case 1:
					echo "<button disabled>已发货，</button>&nbsp;<button onclick='location=\"do_order.php?act=update&status=2&id={$row['id']}\"'>确认完成</button>";
					break;
					case 2:
					echo "订单已完成!";
					break;
				}
				?></td>
    </tr>
  </table>
</div>