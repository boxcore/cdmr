<?php

	$arr_name=explode(' ',$_GET['keywords']);

	if(!empty($arr_name)){
		foreach($arr_name as $arr_name_val){
			$where[]="name like '%{$arr_name_val}%'";
		}
		$url[]=$_GET['name'];
	}
	if(count($where)>0){
		$where="where ".join(" and ",$where);
		$url="&".join("&",$url);
	}
	
	switch($page_name){
		case "category.php":
		$where="where bid in(select id from brand where cid=$cat_id)";
		$h_name=$cat_name;
		break;
		case "brand.php":
		$where="where bid=$brand_id";
		$h_name=$brand_name;
		break;
	}
	
		

	$page=$_GET['page']?$_GET['page']:1;
	$length=$_GET['length']?$_GET['length']:8;

	//获取总页数 int $tot 总页数
	$sql_c="select count(*) from goods {$where} and cartup=1 ";
	$row_c=mysql_fetch_row(mysql_query($sql_c));
	$tot=$row_c[0];

	$pagenum=ceil($tot/$length);
	$offset=($page-1)*$length;
	
	$prev=$page-1;
	if($page<=1){
		$prev=1; 
	}

	$next=$page+1;
	if($page>=$pagenum){
		$next=$pagenum; 
	}


?>

<div id='tlist' class=''>
	<div class='bc'>
		<h1><?php echo $h_name; ?></h1><strong></strong>
		<div class='extra fr'>查询结果 共<?php echo $tot; ?>条</div>
	</div>
</div>
<div id='plist' class='' >
	<ul class='list-h'>
		<?php
			$sql_g="select * from goods {$where} and cartup=1 order by id desc limit $offset,$length";
			$rows_g=mysql_query($sql_g);
			while($row_g=mysql_fetch_assoc($rows_g)){
				echo "<li>";
				echo "<div class='p-img'><a href='goods.php?id={$row_g['id']}' target='_blank'><img src='images/{$row_g['pic']}' width='160' height='160' /></a></div>";
				echo "<div class='p-name'><a href='goods.php?id={$row_g['id']}' target='_blank'>{$row_g['name']}</a></div>";
				echo "<div class='p-price'>￥{$row_g['price']}</div>";
				echo "<div class='extra'><span class='evaluate'><a href='goods.php?id={$row_g['id']}#comment' target='_blank'>已有";
				goodsMC($row_g['id']);
				echo "人评价</a></span><span class='reputation'>好评率</span></div>";
				echo "</li>";
			}
	?>
    </ul>
</div>

