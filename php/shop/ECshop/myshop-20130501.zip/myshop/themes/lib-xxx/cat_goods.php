<?php
$sql_c="select * from category where id=1";
$row_c=mysql_fetch_assoc(mysql_query($sql_c));
?>
<div class="cat_goods">
	<div class='ct'>
		<h2><?php echo $row_c['cname']; ?></h2>
		<div class='bd'>
			<?php
			$sql_b="select * from brand where cid={$row_c['id']}";
			$rows_b=mysql_query($sql_b);
			while($row_b=mysql_fetch_assoc($rows_b)){
				echo "<a href='brand.php?id={$row_b['id']}'>{$row_b['bname']}</a> / ";
			}
			?>
		</div>
		<div class='extra'></div>
	</div>
	<div class='cg'>
		<!--<div class='da da180x348'><a href=''><img src='' /></a></div>-->
		<ul class='list'>
			<?php
				$sql_bl="select * from goods where bid in(select id from brand where cid=1) order by id desc limit 0,8";
				$rows_bl=mysql_query($sql_bl);
				while($row_bl=mysql_fetch_assoc($rows_bl)){
					echo "<li>";
					echo "<div class='p-img'><a target='_blank' href=''><img src='images/{$row_bl['pic']}' width='100' height='100'/></a></div>";
					echo "<div class='p-name'><a target='_blank' href=''>{$row_bl['name']}</a></div>";
					echo "<div class='p-price'>售价<strong>￥{$row_bl['price']}</strong></div>";
					echo "</li>";
				}
			?>
		</ul>
	</div>
</div>
	
<div class='clr'></div>
	
<div class='cat_goods mt10'>
	<div class='ct'>
		<h2>分类名称</h2>
		<div class='bd'>
			<a href=''>品牌名</a>/
		</div>
		<div class='extra'></div>
	</div>
	<div class='cg'>
		<!--<div class='da da180x348'><a href=''><img src='' /></a></div>-->
		<ul class='list'>
			<li>
			<div class='p-img'><a target='_blank' href=''><img src='http://localhost/360buy/images/201203/thumb_img/1_thumb_G_1331565157288.jpg' width='100' height='100'/></a></div>
			<div class='p-name'><a target='_blank' href=''>商品名称</a></div>
			<div class='p-price'>售价<strong>$3344</strong></div>
			</li>
		</ul>
	</div>
</div>

<div class='clr'></div>

