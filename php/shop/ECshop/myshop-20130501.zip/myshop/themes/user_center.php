<style>
#user_tree{}
#user_tree .cap{height: 24px;padding: 3px 8px;background-color:#D80000;line-height: 24px;}
#user_tree .cap h2{color:#fff; text-align:center;}
#user_tree .list{width: 209px;border: solid #D80000;border-width: 0 1px 1px;padding: 6px 0 0;background: #FCF4EA;}
#user_tree .list ul{padding: 6px 0 6px 6px;overflow: hidden;display:block;}
#user_tree .list ul li{float: left;width: 200px;height: 25px;padding: 3px 4px 3px 0;overflow: hidden; text-align:center;}


</style>

<div id="user_tree">
	<div class="cap">
		<h2>用户中心</h2>
	</div>
	<div class="list">
		<ul>
        	<li class=""><a href="user_area.php?act=main" >欢迎首页</a></li>
            <li class=""><a href="user_area.php?act=info" >用户信息</a></li>
            <li class=""><a href="user_area.php?act=order" >我的订单</a></li>
            <li class=""><a href="user_area.php?act=addr" >收货地址</a></li>
            <li class=""><a href="user_area.php?act=commit" >我的评论</a></li>
            <li class=""><a href="user_area.php?act=cash" >资金管理</a></li>
            <li class="red"><a href="user.php?act=logout" >退出中心</a></li>
        </ul>
	</div>
</div>
