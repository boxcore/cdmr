<div class="blank"></div>
<form name="formLogin" action="user.php?act=add&" method="post">
    <div class="w" id="entry">
      <div class="mt">
        <h2>注册新用户</h2>
        <b></b> </div>
      <div class="mc" style="padding-top:20px;">
        <div class="form">
          <div class="item">
          	<span class="label">用户名：</span>
            <div class="fl"><input type="text" id="username" name="username" class="text" tabindex="1" value=""></div>
          </div>
          <div class="item"> <span class="label">密码：</span>
            <div class="fl">
              <input type="password" id="password" name="password" class="text" tabindex="2">
            </div>
          </div>

          <div class="item">
          	<span class="label">中文全名：</span>
            <div class="fl"><input type="text" id="realname" name="realname" class="text" tabindex="1" value=""></div>
          </div>
          
          <div class="item">
          	<span class="label">电子邮箱：</span>
            <div class="fl"><input type="text" id="mail" name="mail" class="text" tabindex="1" value=""></div>
          </div>
          
          <div class="item">
          	<span class="label">手机(电话)：</span>
            <div class="fl"><input type="text" id="tel" name="tel" class="text" tabindex="1" value=""></div>
          </div>
          <div class="item">
          	<span class="label">地址：</span>
            <div class="fl"><input type="text" id="addr" name="addr" class="text" tabindex="1" value=""></div>
          </div>
          <div class="item">
          	<span class="label">密保问题：</span>
            <div class="fl"><input type="text" id="question" name="question" class="text" tabindex="1" value=""></div>
          </div>
          <div class="item">
          	<span class="label">密保答案：</span>
            <div class="fl"><input type="text" id="answer" name="answer" class="text" tabindex="1" value=""></div>
          </div>

		            <div class="item" id="o-authcode"> <span class="label">验证码：</span>
            <div class="fl">
              <input type="text" id="captcha" style="ime-mode:disabled" name="captcha" class="text text-1" tabindex="6">
              <label class="img"> <img src="captcha.php" alt="captcha" style="vertical-align: middle;cursor: pointer;" onclick="this.src='captcha.php?'+Math.random()" id="login_captcha"> </label>
            </div>
          </div>
		            <div class="item" id="autoentry"> <span class="label">&nbsp;</span>
          </div>
          <div class="item"> <span class="label">&nbsp;</span>
		  <input type="hidden" name="act" value="check">
            <input type="submit" name="submit" class="btn-img btn-entry" value="注册" tabindex="8">
            <input type="reset" name="submit" class="btn-img btn-entry" value="重置" tabindex="8">
          </div>
        </div>
        <!--[if !ie]>form end<![endif]-->
        <div id="guide">
          <h5>已注册用户？</h5>
          <div class="content">点击下面的链接去登陆页面吧！</div>
          <a href="user.php?act=login" class="btn-link btn-personal">去登陆页面</a> </div>
        <!--[if !ie]>guide end<![endif]-->
        <span class="clr"></span> </div>
      <!--[if !ie]>mc end<![endif]-->
    </div>
    <!--[if !ie]>regist end<![endif]-->
  </form>
  <div class="blank"></div>