<div name="comment" id="comment">
  <div id="gcommit" >
  <?php
  $sql_m="select * from commit where pid=$id order by id desc limit 0,10";
  $rows_m=mysql_query($sql_m);
  if(mysql_num_rows($rows_m)){
  while($row_m=mysql_fetch_assoc($rows_m)){
	  $sql_u="select user.username from user where id=$row_m[uid]";
	  if($row_u=mysql_fetch_assoc(mysql_query($sql_u))){
		  $mname=$row_u['username'];
	  }else{
		  $mname="匿名用户";
	  }
	  echo "
	  <div class='item'>
      <div class='user'> <span class='u-name'>用户名：{$mname}</span> <span class='date-ask'>".date("Y-m-d H:i:s",$row_m['time'])."</span> </div>
      <dl class='ask'>
        <dt>评论内容：</dt>
        <dd>{$row_m['content']}</dd>
      </dl>
    </div>";
  }
  }else{
	  echo "
	  <div class='item'><center><h1>暂无评论，抢个沙发吧！</h1></center></div>";
	  
  }
  ?>
  </div>
  <a name="qa_form"></a>
  <div class="mc  choose_form">
    <form action="include/commit-insert.php" method="post" name="commentForm" id="commentForm">
      <table border="0" cellspacing="2" cellpadding="0" width="100%">
        <tbody>
          <tr>
            <td colspan="2" height="25px" style="font-size:14px; font-weight:bold; padding-left:10px; background-color:#F2F2F2; color:#CC3300">评论</td>
          </tr>
          <tr>
            <td width="85" height="25px" align="right">用户名：</td>
            <td align="left"><?php if($_SESSION["user_name"]){echo $_SESSION["user_name"];}else{echo "匿名用户";} ?></td>
          </tr>
          <tr>
            <td align="right" height="25px">E-mail：</td>
            <td align="left"><input type="text" name="email" id="email" class="form_email" maxlength="100" value="<?php echo $_SESSION["user_mail"]; ?>" style="border:1px solid #ccc; height:22px; line-height:22px; "></td>
          </tr>
          <tr>
            <td align="right" valign="top" height="25px">内容：</td>
            <td align="left"><textarea name="content" id="comment_content2" style="border:1px solid #ccc; height:100px; width:550px; font-size:12px"></textarea></td>
          </tr>
          <tr>
            <td align="right" valign="top" height="25px">验证码：</td>
            <td><div style="text-align:left; float:left;">
                <table border="0" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr>
                      <td><input type="text" name="captcha" style="border:1px solid #ccc; width:50px;height:22px; line-height:22px;"></td>
                      <td align="left" style="padding-left:5px;"><img src="captcha.php" style="cursor:pointer" alt="看不清楚，点击刷新！" onclick="this.src='captcha.php?r='+Math.random()"></td>
                    </tr>
                  </tbody>
                </table>
              </div></td>
          </tr>
          <tr>
            <td align="right" valign="top" height="25px"></td>
            <td height="40px">
            	<input type="hidden" name="pid" value="<?php echo $id; ?>">

              <input type="hidden" name="uid" value="<?php echo $_SESSION["user_id"]; ?>">
              <input name="" type="submit" value="  提交  " style="padding:2px 20px"></td>
          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>
