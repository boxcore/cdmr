<?php
switch($page_name){
	case "brand.php":
	echo "当前位置：<a href='/myshop/'>首页</a><code>&nbsp;&gt;&nbsp;</code><a href='category.php?id=$cat_id'>{$cat_name}</a><code>&nbsp;&gt;&nbsp;</code>{$brand_name}";
	break;
	case "goods.php":
	echo "当前位置：<a href='/myshop/'>首页</a><code>&nbsp;&gt;&nbsp;</code><a href='category.php?id=$cat_id'>{$cat_name}</a><code>&nbsp;&gt;&nbsp;</code><a href='brand.php?id=$brand_id'>{$brand_name}</a><code>&nbsp;&gt;&nbsp;</code>{$name}";
	break;
	case "user_area.php":
	echo "当前位置：<a href='/myshop/'>首页</a><code>&nbsp;&gt;&nbsp;</code>用户中心";
	break;
	case "search.php":
	echo "当前位置：<a href='/myshop/'>首页</a><code>&nbsp;&gt;&nbsp;</code>搜索<code>&nbsp;&gt;&nbsp;</code>{$_GET['keywords']}";
	break;
	
}
?>