<div class="box">
     <div class="box_1">
      <div class="userCenterBox boxCenterList clearfix" style="_height:1%;">
      <h5><span>用户中心首页</span></h5>
      <div class="blank"></div>
      <p>欢迎登陆，这里你可以操做用户相关信息</p>
      </div>
     </div>
    </div>