<div id="search">
<div class="i-search ld">
<b></b><s></s>
<ul id="shelper" class="hide">
</ul>
<div class="form">
<script type="text/javascript">
		
		<!--
		function checkSearchForm()
		{
			if(document.getElementById('key').value)
			{
				return true;
			}
			else
			{
				alert("请输入搜索关键词！");
				return false;
			}
		}
		-->
		
		</script>
<form id="searchForm" name="searchForm" method="get" action="search.php" onsubmit="return checkSearchForm()">
<input type="text" class="text" accesskey="s" id="key" name="keywords" autocomplete="off" onkeydown="javascript:if(event.keyCode==13) return checkSearchForm();" style="color: rgb(153, 153, 153);">
<input type="submit" value="搜索" class="button" clstag="homepage|keycount|home2012|03a">
</form>
</div>
</div>
<script> (function(){
var B=["请输入商品关键字"];
B=pageConfig.FN_GetRandomData(B);$("#key").val(B).bind("focus",function(){if (this.value==B){this.value="";this.style.color="#333"}}).bind("blur",function(){if (!this.value){this.value=B;this.style.color="#999"}});
})();</script>
<div id="hotwords" clstag="homepage|keycount|home2012|03b"> <strong>热门搜索：</strong>  <a href="search.php?keywords=D-Link%E6%97%A0%E7%BA%BF%E8%B7%AF%E7%94%B1">D-Link无线路由</a>  <a href="search.php?keywords=%E4%BC%91%E9%97%B2%E7%94%B7%E9%9E%8B">休闲男鞋</a>  <a href="search.php?keywords=TCL%E7%A9%BA%E8%B0%83">TCL空调</a>  <a href="search.php?keywords=ELLE">ELLE</a>  </div>
</div>