<div id="cat-tree">
  <div class="cap">
    <h2>所有分类</h2>
  </div>
  <div class="list">
    <?php
			$sql_c="select * from category";
			$rows_c=mysql_query($sql_c);
			while($row_c=mysql_fetch_assoc($rows_c)){
				echo "<div class='category'><h3><a href='category.php?id={$row_c['id']}'>{$row_c['cname']}</a></h3></div>
				
				<ul>";
				$sql_b="select * from brand where cid={$row_c['id']}";
				$rows_b=mysql_query($sql_b);
				while($row_b=mysql_fetch_assoc($rows_b)){
					echo "
						<li><a href='brand.php?id={$row_b['id']}'>{$row_b['bname']}</a></li>													
					";
				}
				echo "</ul>";
			}
		?>
  </div>
</div>
