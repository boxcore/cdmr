<div class="box">
  <div class="box_1">
    <div class="userCenterBox boxCenterList clearfix" style="_height:1%;">
      <h5><span>个人资料</span></h5>
      <div class="blank"></div>
      <form name="formEdit" action="user_area.php?act=baseinfo&" method="post">
        <table width="100%" border="0" cellpadding="5" cellspacing="1" bgcolor="#dddddd">
          <tbody>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">电子邮件地址： </td>
              <td width="72%" align="left" bgcolor="#FFFFFF"><input name="mail" type="text" value="<?php echo $row_u["mail"]; ?>" size="25" class="inputBg">
                <span style="color:#FF0000"> *</span></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">真实姓名：</td>
              <td width="72%" align="left" bgcolor="#FFFFFF"><input name="realname" type="text" class="inputBg" value="<?php echo $row_u["realname"]; ?>"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">手机：</td>
              <td width="72%" align="left" bgcolor="#FFFFFF"><input name="tel" type="text" class="inputBg" value="<?php echo $row_u["tel"]; ?>"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">地址：</td>
              <td width="72%" align="left" bgcolor="#FFFFFF"><input name="addr" type="text" class="inputBg" value="<?php echo $row_u["addr"]; ?>"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF"></td>
              <td width="72%" align="left" bgcolor="#FFFFFF"><input name="act" type="hidden" value="baseinfo">
                <input name="submit" class="btn_submit" type="submit" value="确认修改"></td>
            </tr>
          </tbody>
        </table>
      </form>
      <form name="formPassword" action="user_area.php?act=pass&" method="post">
        <table width="100%" border="0" cellpadding="5" cellspacing="1" bgcolor="#dddddd" style="margin-top:5px;">
          <tbody>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">原密码：</td>
              <td width="76%" align="left" bgcolor="#FFFFFF"><input name="old_password" type="password" size="25" class="inputBg"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">新密码：</td>
              <td align="left" bgcolor="#FFFFFF"><input name="new_password" type="password" size="25" class="inputBg"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF">确认密码：</td>
              <td align="left" bgcolor="#FFFFFF"><input name="comfirm_password" type="password" size="25" class="inputBg"></td>
            </tr>
            <tr>
              <td width="28%" align="right" bgcolor="#FFFFFF"></td>
              <td align="left" bgcolor="#FFFFFF"><input name="act" type="hidden" value="pass">
                <input name="submit" type="submit" value="确认修改" class="btn_submit"></td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  </div>
</div>
