<?php if($_SESSION['login']==1){ ?>
你好，<?php echo $_SESSION['user_name']; ?><a href="user_area.php?act=main">[用户中心]</a>&nbsp;<a href="user.php?act=logout" style="color:gray">[退出]</a>
<?php }else{ ?>
欢迎来MySHOP！<a href="user.php?act=login">[登录]</a>&nbsp;<a href="user.php?act=register">[免费注册]</a>
<?php } ?>