<div class="box">
  <div class="box_1">
    <div class="userCenterBox boxCenterList clearfix" style="_height:1%;">
      <h5><span>我的订单</span></h5>
      <div class="blank"></div>
      <table width="100%" border="0" cellpadding="5" cellspacing="1" bgcolor="#dddddd">
        <tr align="center">
          <th bgcolor="#ffffff">订单号</th>
          <th width="150" bgcolor="#ffffff">下单时间</th>
          <th bgcolor="#ffffff">数量</th>
          <th bgcolor="#ffffff">总价</th>
          <th bgcolor="#ffffff">订单操作</th>
        </tr>
        <?php
                $sql="select * from ordertab where uid='{$user_id}' order by time desc ";
                $rows=mysql_query($sql);
				if(mysql_num_rows($rows)){
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>";
                    echo "<td bgcolor='#ffffff'><a href='user_area.php?act=order_list&id={$row['id']}'>{$row['sn']}</a></td>";
					/*$sql_u="select user.username from user where id={$row['uid']}";
					$row_u=mysql_fetch_assoc(mysql_query($sql_u));
					echo "<td bgcolor='#ffffff'>{$row_u['username']}</td>";*/
					echo "<td align='center' bgcolor='#ffffff'>".date('Y-m-d H:i:s',$row['time'])."</td>";
						
						$goods=json_decode(urldecode($row["info"]),true);
						$tot=0;
						$num=0;
						foreach($goods as $shop){
                            $tot+=$shop['price']*$shop['num'];
                            $num+=$shop['num'];
                        }
						
                        echo "<td bgcolor='#ffffff'>{$num}</td>
                        <td bgcolor='#ffffff' align='right'>￥{$tot}</td>
						<td align='center' bgcolor='#ffffff'>";
						switch($row['status']){
							case 0:
							echo "未发货";
							break;
							case 1:
							echo "已发货 <button onclick='location=\"admin/orders/do_order.php?act=update&status=2&id={$row['id']}\"'>确认收货</button>";
							break;
							case 2:
							echo "已完成";
							break;		
						}
						echo "</tr>";
                }
				}else{
					echo "<tr><td colspan='9' align='center' bgcolor='#ffffff'>呃，订单为空，赶紧买一个把~~</td></tr>";
				}
            ?>
      </table>
      <div class="blank5"></div>
    </div>
  </div>
</div>
