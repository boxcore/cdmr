<?php
if($page_name="brand.php"){
	$sql_bc="select * from brand where id={$brand_id}";
	$row_bc=mysql_query($sql_bc);
	$cat_id=$row_bc['id'];
}
if($page_name="category.php"){
	$cat_id=$_GET['id'];
}
$sql_cb="select distinct bid  from goods where bid in (select brand.id from brand where cid={$cat_id})";
if(mysql_num_rows(mysql_query($sql_cb))){
$rows_cb=mysql_query($sql_cb);
while($row_cb=mysql_fetch_assoc($rows_cb)){
	$arr_cb[]=$row_cb['bid'];
}
shuffle($arr_cb);

$sql_blt="select * from goods where bid={$arr_cb[0]} limit 0,1";

?>
<div class="cat_goods">
	<div class='ct'>
		<?php
		$sql_b="select * from brand where id={$arr_cb[0]}";
		$row_b=mysql_fetch_assoc(mysql_query($sql_b));
		?>
		<h2>随机品牌：<?php echo $row_b['bname']; ?></h2>
		<div class='bd'>
		</div>
		<div class='extra'></div>
	</div>
	<div class='cg'>
		<ul class='list'>
			<?php
				$sql_bl="select * from goods where bid={$arr_cb[0]} and cartup=1 order by id desc limit 0,4";
				$rows_bl=mysql_query($sql_bl);
				while($row_bl=mysql_fetch_assoc($rows_bl)){
					echo "<li>";
					echo "<div class='p-img'><a target='_blank' href='goods.php?id={$row_bl['id']}'><img src='images/{$row_bl['pic']}' width='100' height='100'/></a></div>";
					echo "<div class='p-name'><a target='_blank' href='goods.php?id={$row_bl['id']}'>{$row_bl['name']}</a></div>";
					echo "<div class='p-price'>售价<strong>￥{$row_bl['price']}</strong></div>";
					echo "</li>";
				}
			?>
		</ul>
	</div>
</div>
	
<div class='clr'></div>
<?php } ?>
