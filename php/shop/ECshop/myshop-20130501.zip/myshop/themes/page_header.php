<div id="topbar">
  <div class="w">
    <ul class="fl">
      <li class="fore1">您好，欢迎来到Myshop！</li>
    </ul>
    <ul class="fr w-bar">
      <li class="fore1" id="loginbar">
        <?php @include("themes/user_bar.php"); ?>
      </li>
      <li class="fore2"> <s></s> <a href="" rel="nofollow">我的订单</a> </li>
    </ul>
    <span class="clr"></span> </div>
</div>
<div id="header">
  <div class="w" id="header-logo">
    <div id="logo"> <a href="/myshop/"><img src="themes/images/logo.gif" width="259" height="50" /></a> </div>
    <div id="search">
      <div class="i-search ld"> <b></b><s></s>
        <ul id="shelper" class="hide">
        </ul>
        <div class="form"> 
          <script type="text/javascript">
		
		<!--
		function checkSearchForm()
		{
			if(document.getElementById('key').value)
			{
				return true;
			}
			else
			{
				alert("请输入搜索关键词！");
				return false;
			}
		}
		-->
		
		</script>
          <form id="searchForm" name="searchForm" method="get" action="search.php" onsubmit="return checkSearchForm()">
            <input type="text" class="text" accesskey="s" id="key" name="keywords" onkeydown="javascript:if(event.keyCode==13) return checkSearchForm();" style="color: rgb(153, 153, 153);" value="<?php echo $_GET["keywords"]; ?>">
            <input type="submit" value="搜索" class="button" clstag="homepage|keycount|home2012|03a">
          </form>
        </div>
      </div>
      <div id="hotwords"> <strong>提醒：多关键词搜索请用空格隔开！</strong></div>
    </div>
    <div id="flow">
      <dl class="">
        <dt class="ld"> <a href="flow.php">
          <?php
						//取购物车总数和总价
						if($_SESSION["shops"]){
						foreach($_SESSION["shops"] as $goods){
							$totnum+=$goods['num'];
							$tot+=$goods['num']*$goods['price'];
						}
						echo "共{$totnum}件商品";
						}else{
							echo "购物车为空！";
						}
						?>
          </a> <b></b> </dt>
      </dl>
    </div>
  </div>
  <div class="w">
    <div id="nav">
      <div id="categorys">
        <div class="mt ld">
          <h2><a href="index.php">全部商品分类<b></b></a></h2>
        </div>
      </div>
      <div id="treasure"></div>
      <ul id="navitems">
        <li class="fore1 curr"><a href="index.php">首页</a></li>
        <li class="fore2"> <a href="category.php?id=1">笔记本</a> </li>
        <li class="fore2"> <a href="category.php?id=6">数码相机</a> </li>
        <li class="fore2"><a href="category.php?id=4">手机</a> </li>
        <li class="fore2"><a href="category.php?id=5">鼠标</a> </li>
        <li class="fore2"><a href="category.php?id=3">键盘</a> </li>
      </ul>
    </div>
  </div>
</div>
