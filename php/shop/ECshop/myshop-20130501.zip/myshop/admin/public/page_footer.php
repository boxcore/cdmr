<div id="footer">
产品操作界面，copy自ecshop后台风格，欢迎拷贝<br />
这是底部版权信息页面
</div>
</body>
</html>