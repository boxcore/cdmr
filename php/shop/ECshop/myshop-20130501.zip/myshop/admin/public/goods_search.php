<div class="form-div">
  <form action="<?php echo $page_name; ?>" method="get" name="searchForm">
    <img src="../public/images/icon_search.gif" width="26" height="22" border="0" alt="SEARCH" /> 
    
	<!-- 分类品牌
    <select name="bid">
      <option value="0">所有品牌</option>
      <?php/*
	  $sql_cs="select * from category";
	  $rows_cs=mysql_query($sql_cs);
	  while($row_cs=mysql_fetch_assoc($rows_cs)){
		  echo "<option value='0-{$row_cs['id']}'";
		  if($_GET["bid"]=="0-{$row_cs['id']}"){ echo "selected"; }
		  echo ">{$row_cs['cname']}</option>\n";
		  $sql_bs="select * from brand where cid={$row_cs['id']}";
		  $rows_bs=mysql_query($sql_bs);
		  while($row_bs=mysql_fetch_assoc($rows_bs)){
			  echo "<option value='{$row_bs['id']}'";
			  if($_GET["bid"]=="{$row_bs['id']}"){ echo "selected"; }
			  echo ">&nbsp;&nbsp;&nbsp;&nbsp;{$row_bs['bname']}</option>\n";
		  }
		}*/
	  ?>
    </select>
    
     上架
    <select name="cartup">
      <option value=''>全部</option>
	  <option value="1" <?php //if($_GET["cartup"]===1){ echo "selected"; } ?>>上架</option>
	  <option value="0"  <?php //if($_GET["cartup"]===0){ echo "selected"; } ?>>下架</option>
    </select> -->
    
    <!-- 关键字 --> 
    关键字
    <input type="text" name="<?php echo $search_key; ?>" size="15" value="<?php echo $_GET[$search_key]; ?>" />
    <input type="submit" value="搜索" class="button" />
  </form>
</div>
