<!DOCTYPE html>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../public/css/general.css" rel="stylesheet" type="text/css" />
<link href="../public/css/main.css" rel="stylesheet" type="text/css" />
<?php if($page_name=="edit.php" || $page_name=="add.php"){ ?>
<script charset="utf-8" src="/myshop/admin/include/editor/kindeditor.js"></script>
<script charset="utf-8" src="/myshop/admin/include/editor/lang/zh_CN.js"></script>
<script>
        KindEditor.ready(function(K) {
                window.editor = K.create('#editor_id');
        });
</script>
<?php } ?>
</head>
<body>
	<h1>
		<?php
			//array $page_action||$page_action1 为在当前页面显示的操作选项，下标[0]=链接，下标[1]=链接描述
			if($page_action){ 
				echo "<span class='action-span'><a href='{$page_action[0]}'>{$page_action[1]}</a></span>";
			}
		?>
		<?php 
			if($page_action2){ 
				echo "<span class='action-span'><a href='{$page_action2[0]}'>{$page_action2[1]}</a></span>";
			}
		?>
		<span class="action-span1"><a href="index.php">管理中心</a> </span><span id="search_id" class="action-span1"><?php if($page_here){ echo "  -  ".$page_here; } ?></span>
<div style="clear:both"></div>
</h1>

