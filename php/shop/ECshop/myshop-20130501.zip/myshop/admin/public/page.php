<div id="turn-page">
        总计  <span id="totalRecords"><?php echo $tot; ?></span>
        个记录分为 <span id="totalPages"><?php echo $pagenum; ?></span>
        页当前第 <span id="pageCurrent">
		<?php 
		if($_GET["page"]){
			echo $_GET["page"];
		}else{
			echo 1;
		} 
		?></span>
        页，每页<?php echo $length; ?>条记录
        <span id="page-link">
          <a href="<?php echo $page_name; ?>?page=1&<?php echo $url; ?>">第一页</a>
          <a href='<?php echo $page_name; ?>?page=<?php echo $prev; ?>&<?php echo $url; ?>'>上一页</a>
          <a href="<?php echo $page_name; ?>?page=<?php echo $next; ?>&<?php echo $url; ?>">下一页</a>
          <a href="<?php echo $page_name; ?>?page=<?php echo $pagenum; ?>&<?php echo $url; ?>">最末页</a>
        </span>
      </div>
