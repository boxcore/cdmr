<div class="form-div">
  <form action="<?php echo $page_name; ?>" method="get" name="searchForm">
    <img src="../public/images/icon_search.gif" width="26" height="22" border="0" alt="SEARCH" />
    <!-- 关键字 -->
    关键字 <input type="text" name="<?php echo $search_key; ?>" size="15" value="<?php echo $_GET[$search_key]; ?>" />
    <input type="submit" value="搜索" class="button" />
  </form>
</div>