<?php  
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:login.php");
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>管理首页</title>
    <style type="text/css">
    </style>
</head>
<body>
	<h2>显示内容</h2>
	<p>灰常欢迎您的到来，这里是管理平台，你拥有这宇宙最伟大的权限！enjoy it！！<br>参与开发的人员有:<br>
	<b>hcz</b>
	<i>take</i>
	</p>


</html>



