<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
    $id=$_GET['id'];
	$delpic=$_GET['delpic'];
	$sql="delete from goods where id={$id}";
    if(mysql_query($sql)){
		if($delpic){
		unlink("../../images/{$delpic}");
		unlink("../../images/".substr($delpic,4));
		}
        header("location:index.php"); 
    }
