<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
include("../../include/func.php");

if($_FILES['pic']['error']===0){
    $picfile=upload("pic","../../images/");
    $pic=thumb($picfile,100,100);
    if($_POST['oldpic']){
		unlink("../../images/{$_POST['oldpic']}");
    	unlink("../../images/".substr($_POST['oldpic'],4));
	}
}else{
    $pic=$_POST['oldpic'];
}
$name=$_POST['name'];
$price=$_POST['price'];
$stock=$_POST['stock'];
$bid=$_POST['bid'];
$cartup=$_POST['cartup'];

$sql="update goods set name='{$name}',pic='{$pic}',price='{$price}',stock='{$stock}',cartup='{$cartup}',bid='{$bid}' where id={$_POST['id']}";

if(mysql_query($sql)){
    header("location:index.php");
}
