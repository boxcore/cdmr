<?php
include("../../include/init.php");
include("../../include/func.php");

$name=$_POST['name'];
$price=$_POST['price'];
$stock=$_POST['stock'];
$bid=$_POST['bid'];
$time=time();
if($_POST['pic']){
$picfile=upload("pic","../public/upload/");
$pic=thumb($picfile,100,100);
}
$sql="insert into goods(name,pic,price,stock,bid,time) values('{$name}','{$pic}','{$price}','{$stock}','{$bid}','{$time}')";

if(mysql_query($sql)){
    header("location:index.php");
}
