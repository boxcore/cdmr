<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");

    $id=$_GET['id'];
    $sql="select * from goods where id={$id}";
    $rows=mysql_query($sql);
    $row=mysql_fetch_assoc($rows);
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id=div1>
        <h2 id="hid">商品编辑</h2>
        <table width="400px" cellspacing=0 border="1px">
        <form id="fid" action="update.php" method="post" enctype="multipart/form-data">
            <tr>
                <td>商品名称:</td><td><input id="userid" name="name" type="text" value="<?php echo $row['name'] ?>"></td>
            <tr>
            <tr>
                <td>商品图片:</td><td><input id="userid" name="pic" type="file" value="<?php echo $row['pic']?>"></td>
            </tr>
            <tr>
                <td>商品单价:</td><td><input id="userid" name="price" type="text" value="<?php echo $row['price']?>"></td>
            </tr>
            <tr>
                <td>库存量:</td><td><input id="userid" name="stock" type="text" value="<?php echo $row['stock']?>"></td>
            </tr>
            <tr>
                <td>选择品牌:</td>
                <td>
                <select name="bid" id="sid">
                    <option value="default">--选择品牌--</option>
                    <?php
                        $sql2="select * from category order by id";
                        $rows2=mysql_query($sql2);
                        while($row2=mysql_fetch_assoc($rows2)){
                            echo "<option disabled value='{$row2['id']}'>{$row2['cname']}</option>";
                            $sql3="select * from brand where cid={$row2['id']}";
                            $rows3=mysql_query($sql3);
                            while($row3=mysql_fetch_assoc($rows3)){
                                if($row3['id']==$row['bid']){
                                    echo "<option selected value='{$row3['id']}'>-{$row3['bname']}</option>";
                                }else{
                                    echo "<option value='{$row3['id']}'>-{$row3['bname']}</option>";
                                }
                            }
                            //echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
            	<td>是否上架:</td><td><input type="radio" name="cartup" value="0" checked />不上架  &nbsp;<input type="radio" name="cartup" value="1" />上架</td>
            <tr>
                <td colspan="2" align="center"><input name="sub" type="submit" value="单击添加"></td>
            </tr>
            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
            <input type="hidden" name="oldpic" value="<?php echo $row['pic'] ?>">
        </form>    
    </table>
    <img id="imgid" class="img" src="../../images/<?php echo $row['pic'] ?>">
    </div>
    </center>
</body>
<script>
    
</script>
</html>

