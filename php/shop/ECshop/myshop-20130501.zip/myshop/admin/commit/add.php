<?php
    include("../../include/init.php");
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id=div1>
        <h2 id="hid">商品添加</h2>
        <table width="400px" cellspacing=0 border="1px">
        <form id="fid" action="insert.php" method="post" enctype="multipart/form-data">
            <tr>
                <td>商品名称:</td><td><input id="userid" name="name" type="text" value=""></td>
            <tr>
            <tr>
                <td>商品图片:</td><td><input id="userid" name="pic" type="file" value=""></td>
            </tr>
            <tr>
                <td>商品单价:</td><td><input id="userid" name="price" type="text" value=""></td>
            </tr>
            <tr>
                <td>库存量:</td><td><input id="userid" name="stock" type="text" value=""></td>
            </tr>
            <tr>
                <td>选择品牌:</td>
                <td>
                <select name="bid" id="sid">
                    <option value="default">--选择品牌--</option>
                    <?php
                        $sql="select * from category order by id";
                        $rows=mysql_query($sql);
                        while($row=mysql_fetch_assoc($rows)){
                            $sql2="select * from brand where cid={$row['id']}";
                            echo "<option disabled value='{$row['id']}'>{$row['cname']}</option>";
                            $rows2=mysql_query($sql2);
                            while($row2=mysql_fetch_assoc($rows2)){
                                echo "<option value='{$row2['id']}'>-{$row2['bname']}</option>";
                            }
                            //echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input name="sub" type="submit" value="单击添加"></td>
            </tr>
        </form>    
    </table>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
