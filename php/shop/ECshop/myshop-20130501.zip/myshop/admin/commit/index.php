<?php  
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
?>
<?php include("../../include/init.php") ?>
<?php
if($_GET["state"]){
	switch($_GET["state"]){
		case "up":
		$state=1;
		break;
		case "down":
		$state=0;
		break;
	}
	
$sql="update goods set cartup={$state} where id={$_GET['id']}";
$rows=mysql_query($sql);
}
	
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>index</title>
    <style type="text/css">
    </style>
</head>
<body>
    <center>
    <div id=div1>
        <h1 id="hid">商品浏览</h1>
        <h2 id="hid"><a href="add.php">添加商品</a></h2>
        <table border="1" cellspacing=0 width="800px">
            <tr>
                <th>商品编号</th>
                <th>商品名称</th>
                <th>商品图片</th>
                <th>商品单价</th>
                <th>库存量</th>
                <th>添加时间</th>
                <th>上架情况</th>
                <th>品牌名称</th>
                <th>编辑商品</th>
                <th>删除商品</th>
            </tr>
            <?php
                $sql="select goods.id,goods.name sname,goods.pic,goods.price,goods.stock,goods.time,goods.cartup,brand.bname from goods,brand where goods.bid=brand.id";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['sname']}</td>
                        <td><a href='../../images/".substr($row['pic'],4)."' target='_blank'><img src='../../images/{$row['pic']}' /></a></td>
                        <td>{$row['price']}</td>
                        <td>{$row['stock']}</td>
                        <td>{$row['time']}</td>";
						 switch($row['cartup']){
                                    case 0:
                                        echo "<td><a href='index.php?id={$row['id']}&state=up'>上架</a></td>";
                                        break;
                                    case 1:
                                        echo "<td><a href='index.php?id={$row['id']}&state=down'>下架</a></td>";
                                        break;
                                    }

                        
                       echo "<td>{$row['bname']}</td>
                        <td><a href='edit.php?id={$row['id']}'>编辑商品</a></td>
                        <td><a href='del.php?id={$row['id']}&delpic={$row['pic']}'>删除商品</a></td>
                    </tr>";
                }
            ?>
        </table>
    </div>
    </center>
</body>
<script>
    
</script>
</html>
