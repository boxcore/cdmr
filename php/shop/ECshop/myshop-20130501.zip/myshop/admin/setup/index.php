<?php
session_start();
include("../../include/init.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf8" />
    <title>商店常用设置</title>
    <link href="../public/style.css" rel="stylesheet" style="text/css" />
</head>
<body>

<?php
$sql="select id,defname,value from config";
$rows=mysql_query($sql);
while($row=mysql_fetch_assoc($rows)){
	$arr[$row["id"]]=array($row["defname"],$row["value"]);
	}
/*
echo "<pre>";
print_r($arr);
echo "</pre>";
*/

/*
while($row=mysql_fetch_assoc($rows)){
	define($row["defname"],$row['value']);
	}
echo shop_name;
*/
?>
<table>
	<tr>
    	<td>网站地址：</td><td><input type="text" name="<?php echo $arr[1][0] ?>" value="<?php echo $arr[1][1] ?>" /></td>
    </tr>
</table>
</body>
</html>