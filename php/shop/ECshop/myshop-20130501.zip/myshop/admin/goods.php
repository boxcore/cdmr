<?php  
include('include/access1.php');

//修改产品上下架状态
if($_GET["state"]){
	switch($_GET["state"]){
		case "up":
		$state=1;
		break;
		case "down":
		$state=0;
		break;
	}
$sql="update goods set cartup={$state} where id={$_GET['id']}";
$rows=mysql_query($sql);
header("location:index.php#list_{$_GET['id']}");
}	

//页面开始

//初始页面内容
$page_action=array("add.php","添加产品");
$page_here="产品列表";
include("public/page_header.php"); 
?>

<!-- 商品列表 -->

<div class="list-div" id="listDiv">
<div id=div1>
  <table cellpadding="3" cellspacing="1">
    <tr>
      <th>商品编号</th>
      <th>商品名称</th>
      <th>商品图片</th>
      <th>商品单价</th>
      <th>库存量</th>
      <th>添加时间</th>
      <th>上架情况</th>
      <th>品牌名称</th>
      <th>操作</th>
    </tr>
    <?php
                $sql="select goods.id,goods.name sname,goods.pic,goods.price,goods.stock,goods.time,goods.cartup,brand.bname from goods,brand where goods.bid=brand.id";
				$rows=mysql_query($sql);
				if(mysql_num_rows($rows)){
                while($row=mysql_fetch_assoc($rows)){
					echo "
						<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['sname']}</td>
                        <td><a href='../../images/".substr($row['pic'],4)."' target='_blank'><img src='../../images/{$row['pic']}' /></a></td>
                        <td>{$row['price']}</td>
                        <td>{$row['stock']}</td>
                        <td>".date('Y-m-d H:i:s',$row['time'])."</td>";
					   
						switch($row['cartup']){
							case 0:
							echo "<td><a href='index.php?id={$row['id']}&state=up'>上架</a></td>";
							break;
							case 1:
							echo "<td><a href='index.php?id={$row['id']}&state=down'>下架</a></td>";
							break;
						}
						echo "<td>{$row['bname']}</td>
						<td align='center'>
							<a href='../goods.php?id=' target='_blank' title=''><img src='../public/images/icon_view.gif' width='16' height='16' border='0' /></a>
							<a href='edit.php?id={$row['id']}' name='list_{$row['id']}' alt='编辑商品'><img src='../public/images/icon_edit.gif' width='16' height='16' border='0' /></a>
							<a href='del.php?id={$row['id']}&delpic={$row['pic']}'><img src='../public/images/no.gif' width='16' height='16' border='0' /></a></td>
					</tr>";
				}
			}else{
			echo "<tr><td class='no-records' colspan='9'>没有记录</td></tr>";
		} 
	?>
  </table>
  
  <!-- 分页 -->
<table id="page-table" cellspacing="0">
  <tr>
    <td align="right" nowrap="true">
    <?php include("public/page.php"); ?>
    </td>
  </tr>
</table>
</div>
<div style="height:20px"></div>
<?php include("public/page_footer.php"); ?>
