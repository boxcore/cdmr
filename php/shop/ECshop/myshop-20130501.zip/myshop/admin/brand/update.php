<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
header("content-type:text/html;charset=utf8");


    $id=$_POST['id'];
    $bname=$_POST['bname'];
	$cid=$_POST['cid'];
    
    $sql="update brand set bname='{$bname}',cid='{$cid}' where id={$id}";
	
	
    if(mysql_query($sql)){
        header("location:index.php"); 
	}
