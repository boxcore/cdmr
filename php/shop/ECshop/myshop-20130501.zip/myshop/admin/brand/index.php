<?php
/**
 * 品牌管理列表 category/index.php
 * 
*/

include('../include/access1.php');
//初始页面内容
$page_action=array("add.php","添加品牌");
$page_here="品牌管理列表";
$page_name="index.php";
include("../public/page_header.php"); 
?>
<div class="list-div" id="listDiv">
        <table cellpadding="3" cellspacing="1">
            <tr>
            	<th>品牌</th>
                <th>分类</th>
            	<th>编辑</th>
            </tr>
            <?php
                $sql="select * from brand order by cid";
                $rows=mysql_query($sql);
				
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>";
					
					
					$sql2="select * from category where id={$row['cid']} order by id";
					$rows2=mysql_query($sql2);
					$row2=mysql_fetch_assoc($rows2);
                    echo "<td>{$row['bname']}</td>";
					echo "<td>{$row2['cname']}</td>";
                    echo "<td align='center'><a href='edit.php?id={$row['id']}' title='编辑'><img src='../public/images/icon_edit.gif' width='16' height='16' border='0' /></a>&nbsp;<a href='del.php?id={$row['id']}' title='删除'><img src='../public/images/no.gif' width='16' height='16' border='0' /></a></td>
                    </tr>";
					}
				
            ?>
        </table>
</div>
<?php include("../public/page_footer.php"); ?>

