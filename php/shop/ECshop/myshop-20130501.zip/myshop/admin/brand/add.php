<?php
/**
 * 添加品牌 brand/add.php
 * 
*/

include('../include/access1.php');

//初始页面内容
$page_action=array("index.php","品牌列表");
$page_here="添加品牌";
$page_name="add.php";
include("../public/page_header.php"); 
?>
<div class="main-div">
	<form id="fid" action="insert.php" method="post" name="theForm" enctype="multipart/form-data">
<table cellspacing="1" cellpadding="3" width="100%">
  <tr>
    <td class="label">品牌名称：</td>
    <td><input type="text" name="bname" /></td>
    </tr>
    <tr>
    <td class="label">分类：</td>
    <td><select name="cid">
            	<option value="0">--选择分类--</option>
                <?php
			$sql="select * from category order by id";
			$rows=mysql_query($sql);
			
			while($row=mysql_fetch_assoc($rows)){
				
				echo "<option value='{$row['id']}'>{$row['cname']}</option>";
				
			}
			?>
            </select>
            </td>
         </tr>
    <tr>
    <td colspan="2" align="left" style="padding-left:60px"><br />
    <input name="sub" type="submit" class="button" value="添加">&nbsp;<input name="reset" type="reset" class="button" value="重置" />
    </td>
    </tr>
    </table>
	</form>
</div>
<?php include("../public/page_footer.php"); ?>