<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}

include("../../include/init.php");

    $id=$_GET['id'];

    $sql="delete from brand where id={$id}";
    if(mysql_query($sql)){
		header("location:index.php");
	}

