<?php
/**
 * 编辑品牌
 * 
*/

include('../include/access1.php');

//初始页面内容
$page_action=array("index.php","品牌列表");
$page_here="品牌编辑";
$page_name="edit.php";
include("../public/page_header.php"); 
?>
<div class="main-div">
<form id="fid" action="update.php" method="post" name="theForm" enctype="multipart/form-data">
        <table cellspacing="1" cellpadding="3" width="100%">
        <?php
			$id=$_GET["id"];
			$sql="select * from brand where id={$id} order by id";
			$rows=mysql_query($sql);
			$row=mysql_fetch_assoc($rows);
        ?>
			<tr>
				<td class='label'>品牌名称：</td>
				<td><input type='text' name='bname' value='<?php echo $row['bname'] ?>' /></td>
			</tr>
            <tr>
				<td class='label'>分类：</td>
				<td><select name='cid'>
            <?php
			$sql2="select * from category where id={$row['cid']}";
			$rows2=mysql_query($sql2);
			$row2=mysql_fetch_assoc($rows2);
			echo "<option value='{$row2['id']}' selected>{$row2['cname']}</option>";
			$sql2="select * from category order by id";
			$rows2=mysql_query($sql2);
			while($row2=mysql_fetch_assoc($rows2)){
			echo "<option value='{$row2['id']}'>{$row2['cname']}</option>";
			}
			?>
            </select></td>
			</tr>       
<tr>
    <td colspan="2" align="left" style="padding-left:60px"><br />
    <input type='hidden' name='id' value='<?php echo $row['id'] ?>' />
    <input name="sub" type="submit" class="button" value="保存">&nbsp;<input name="reset" class="button" type="reset" value="重置" />
    </td>
  </tr>
</table>
</form>
</div>
<?php include("../public/page_footer.php"); ?>
