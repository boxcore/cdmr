<?php
    session_start();

    $username=$_POST['username'];
    $password=$_POST['password'];

    include("../include/init.php");
	$sql="select * from user where username='{$username}' and password='{$password}' and admin=1";
    $rows=mysql_query($sql);
    if(mysql_num_rows($rows)>0){
        $_SESSION["user_name"]=$username;
        $row=mysql_fetch_row($rows);
        $_SESSION["user_id"]=$row[0];
        $_SESSION["padmin"]=$row[3];
        $_SESSION["login"]=1;
		echo "<script>location='index.php'</script>";
    }else{
        echo "<script>location='login.php'</script>";
    }

