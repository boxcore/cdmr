<?php
header("content-type:text/html;charset=utf8");
include("include/access.php");
include("../include/init.php");
/* @list
 * 显示产品分类列表
 * 
 */

 if ($_REQUEST["act"]=="list"){
	$sql="select * from cats";
	$rows=mysql_query($sql);
	
	echo "<h1>产品分类列表</h1>";
	echo "<table border=1 cellspacing=0 width=700>";
	echo "<tr><th>序列</th><th>产品分类</th><th>编辑</th></tr>";
	while($row=mysql_fetch_row($rows)){
	echo "<tr>";
	echo "<td>{$row[0]}</td>";
	echo "<td>{$row[1]}</td>";
	echo "<td><a href='cats.php?act=edit&id={$row[0]}'>编辑</a>\n<a href='cats.php?act=del&id={$row[0]}'>删除</a></td>";
	echo "</tr>";
	}
	echo "</table>";
echo "<h3><a href='cats.php?act=add'>添加产品分类</a></h3>";
}



/* @add
 * 添加产品分类列表
 * 
 */
elseif ($_REQUEST["act"]=="add"){
	echo "<h1>添加产品分类</h1>";
	echo "<form method=get action='cats.php'>";
	echo "新建产品分类名称：<input type='text' name='insert' />";
	echo "<input type='submit' value='提交' />";
	echo "</from>";

}


/*处理添加产品分类数据的语句
 *
 *
 */
elseif ($_REQUEST["insert"]){

	$sql="insert into cats (name) values ('{$_REQUEST['insert']}')";

	if(mysql_query($sql)){
		echo "<script>location='cats.php?act=list'</script>";
	}
}


/*处理删除产品分类的语句
 *
 *
 */
elseif ($_REQUEST["act"]=="del"){
	$sql="delete from cats where id={$_REQUEST["id"]}";
	$result=mysql_query($sql);
	if(mysql_query($sql)){
		header("location:cats.php?act=list");
	}
}

/*编辑产品分类
 *
 *
 */
elseif ($_REQUEST["act"]=="edit"){
	$sql="select * from cats where id={$_REQUEST['id']}";
	$result=mysql_query($sql);
	$row=mysql_fetch_row($result);


	echo "<h1>编辑产品分类</h1>";
	echo "<form method=get action='cats.php'>";
	echo "将产品分类{$row[1]}更改为<input type='text' name='update' value='{$row[1]}' />";
	echo "<input type='hidden' name='id' value='{$row[0]}' />";
	echo "<input type='submit' value='提交' />";
	echo "</from>";
}

/*编辑产品分类语句
 *
 *
 */
elseif ($_REQUEST["update"]){
	$sql="update cats set name='{$_REQUEST['update']}' where id={$_REQUEST['id']}";
	$result=mysql_query($sql);
	if(mysql_query($sql)){
		header("location:cats.php?act=list");
	}
}

?>


