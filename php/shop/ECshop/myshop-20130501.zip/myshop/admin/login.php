<?php 
	session_start();
if($_SESSION['padmin']==1){
	header("location:index.php");
}

include('public/login.html');
?>
