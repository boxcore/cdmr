<?php
/* 权限控制
 *
 *
 */
session_start(); 
if($_SESSION["login"]==0 || $_SESSION['padmin']==0){
	header("location:../login.php");
}
include(dirname(__FILE__).'../../../include/init.php');
?>
