<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
header("content-type:text/html;charset=utf8");


    $id=$_POST['id'];
    $cname=$_POST['cname'];
    
    $sql="update category set cname='{$cname}' where id={$id}";
	
	
    if(mysql_query($sql)){
        header("location:index.php"); 
	}
