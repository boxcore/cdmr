<?php
/**
 * 编辑分类
 * 
*/

include('../include/access1.php');

//初始页面内容
$page_action=array("index.php","分类列表");
$page_here="分类编辑";
$page_name="edit.php";
include("../public/page_header.php"); 
?>
<div class="main-div">
		<?php
            $id=$_GET['id'];
            $sql="select * from category where id={$id}";
            $rows=mysql_query($sql);
            $row=mysql_fetch_assoc($rows);
        ?>    
<form id="fid" action="update.php" method="post">
<table cellspacing="1" cellpadding="3" width="100%">
<tr>
<td class="label">分类名称：</td>
<td><input type="text" name="cname" value="<?php echo $row["cname"] ?>" />
</td>
</tr>
</table>
<div class="button-div">
        <input type="submit" value=" 确定 " />
        <input type="reset" value=" 重置 " />
        <input type="hidden" name="id" value="<?php echo $id ?>" />
</div>
</form>
</div>
<?php include("../public/page_footer.php"); ?>
