<?php
/**
 * 添加分类 category/add.php
 * 
*/

include('../include/access1.php');

//初始页面内容
$page_action=array("index.php","分类列表");
$page_here="添加分类";
$page_name="add.php";
include("../public/page_header.php"); 
?>
<div class="main-div">
<form id="fid" action="insert.php" method="post">
<table cellspacing="1" cellpadding="3" width="100%">
	<tr>
    	<td class="label">分类名称：</td>
        <td><input type="text" name="cname" /></td>
    </tr>
</table>
<div class="button-div">
        <input type="submit" value=" 确定 " />
        <input type="reset" value=" 重置 " />
</div>
</form>
</div>
<?php include("../public/page_footer.php"); ?>
