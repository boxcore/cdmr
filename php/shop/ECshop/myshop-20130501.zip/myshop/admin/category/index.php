<?php  
include('../include/access1.php');
//初始页面内容
$page_action=array("add.php","添加分类");
$page_here="商品分类";
$page_name="index.php";
include("../public/page_header.php"); 
?>
<!-- 分类列表 -->
<div class="list-div" id="listDiv">
        <table cellpadding="3" cellspacing="1">
            <tr>
            	<th>序列</th>
            	<th>产品分类</th>
            	<th>编辑</th>
            </tr>
            <?php
                $sql="select * from category order by id";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>
                        <td align='center' width='30px'>{$row['id']}</td>
                        <td>{$row['cname']}</td>
                        <td align='center'><a href='edit.php?id={$row['id']}' title='编辑'><img src='../public/images/icon_edit.gif' width='16' height='16' border='0' /></a>&nbsp;<a href='del.php?id={$row['id']}' title='删除'><img src='../public/images/no.gif' width='16' height='16' border='0' /></a></td>
                    </tr>";
					}
				
            ?>
        </table>
</div>
<?php include("../public/page_footer.php"); ?>

