<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
header("content-type:text/html;charset=utf8");
    
	$cname=$_POST['cname'];
    $sql="insert into category (cname) values ('{$cname}')";
    if(mysql_query($sql)){
        header("location:index.php"); 
	}
