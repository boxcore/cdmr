<?php
session_start();
include("../../include/init.php");
$id=$_GET["id"];

if($_GET["act"]=="update"){
	if($_GET["status"]){
		$sql="update ordertab set status={$_GET['status']} where id={$id}";
		if(mysql_query($sql)){
			echo "<script>window.history.go(-1);</script>";
		}
	}
}
if($_GET["act"]=="del"){
	$sql="delete from ordertab where id={$id}";
	if(mysql_query($sql)){
			echo "<script>window.history.go(-1);</script>";
	}
}