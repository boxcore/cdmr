<?php  
include('../include/access1.php');

//加工搜索 和分页
$search_key="sn"; //能用于搜索的字段
foreach($_GET as $key=>$val){
	if(!empty($val) && $key==$search_key){
		$arr[]="$key like '%$val%'";
		$url[]="$key=$val";
	}                 
}

if(is_array($arr)){
	$where="where ".join(" and ",$arr);
	$url=join("&",$url);
}


//页面开始

//初始页面内容
$page_action=array("../user/index.php","用户列表");
$page_here="订单列表";
$page_name="index.php";

include("../public/page_header.php"); 
?>

<!-- 商品搜索 -->
<?php include('../public/goods_search.php'); ?>

<div class="list-div" id="listDiv">
        <table cellpadding="3" cellspacing="1">
            <tr>
                <th>ID</th>
                <th>订单号</th>
                <th width="60">用户名</th>
                <th width="150">下单时间</th>
                <th>数量</th>
                <th>总价</th>
                <th>订单状态</th>
                <th>编辑</th>
                
            </tr>
            <?php
			$page=$_GET['page']?$_GET['page']:1;
                    $length=$_GET['length']?$_GET['length']:4;

                    $sql="select count(*) from ordertab";
                    $rows=mysql_query($sql);
                    $row=mysql_fetch_row($rows);
                    $tot=$row[0];
                    
                    $pagenum=ceil($tot/$length);
                    $offset=($page-1)*$length;
                        
                    $prev=$page-1;
                    if($page<=1){
                        $prev=1; 
                    }

                    $next=$page+1;
                    if($page>=$pagenum){
                        $next=$pagenum; 
                    }
                $sql="select * from ordertab {$where} order by id desc limit $offset,$length";
                $rows=mysql_query($sql);
				if(mysql_num_rows($rows)){
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['sn']}</td>";
					$sql_u="select user.username from user where id={$row['uid']}";
					$row_u=mysql_fetch_assoc(mysql_query($sql_u));
					echo "<td>{$row_u['username']}</td>";
					echo "<td align='center'>".date('Y-m-d H:i:s',$row['time'])."</td>";
						
						$goods=json_decode(urldecode($row["info"]),true);
						$tot2=0;
						$num=0;
						foreach($goods as $shop){
                            $tot2+=$shop['price']*$shop['num'];
                            $num+=$shop['num'];
                        }
						
                        echo "<td>{$num}</td>
                        <td>{$tot2}</td>
						<td align='center'>";
						switch($row['status']){
							case 0:
							echo "未发货 <button onclick='location=\"do_order.php?act=update&status=1&id={$row['id']}\"'>去发货</button>";
							break;
							case 1:
							echo "已发货 <button onclick='location=\"do_order.php?act=update&status=2&id={$row['id']}\"'>确认完成</button>";
							break;
							case 2:
							echo "已确认";
							break;		
						}
						echo "</td>
                        <td><a href='edit.php?id={$row['id']}'>编辑</a>&nbsp;<a href='do_order?act=del&id={$row['id']}'>删除</a></td>
                    </tr>";
                }
				}else{
					echo "<tr><td colspan='9' align='center'>呃，订单为空，不如你自己买一个把~~</td></tr>";
				}
            ?>
        </table>
  <!-- 分页 -->
  <table id="page-table" cellspacing="0">
    <tr>
      <td align="right" nowrap="true"><?php include("../public/page.php"); ?></td>
    </tr>
  </table>
        </div>
<?php include("../public/page_footer.php"); ?>
