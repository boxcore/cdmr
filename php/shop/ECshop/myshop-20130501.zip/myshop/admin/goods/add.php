<?php
include('../include/access1.php');
//初始页面内容
$page_action=array("index.php","商品列表");
$page_here="添加新商品";
$page_name="add.php";
include("../public/page_header.php"); 
?>
<!-- start goods form -->
<div class="tab-div">

<!-- tab bar -->
    <div id="tabbar-div">
      <p>
        <span class="tab-front" id="general-tab">产品信息</span>
      </p>
    </div>
<!-- tab body -->
<div id="tabbody-div">
<form enctype="multipart/form-data" action="insert.php" method="post" name="theForm" >
<div class="button-div">
        <input type="submit" value=" 确定 " class="button" >
        <input type="reset" value=" 重置 " class="button">
    </div>
        <table width="90%" id="general-table" align="center">
            <tr>
                <td class="label">商品名称:</td>
                <td><input id="userid" name="name" type="text" value=""></td>
            <tr>
            <tr>
                <td class="label">商品图片:</td>
                <td><input id="userid" name="pic" type="file"></td>
            </tr>
            <tr>
                <td class="label">商品单价:</td>
                <td><input id="userid" name="price" type="text" value=""></td>
            </tr>
            <tr>
                <td  class="label">库存量:</td>
                <td><input id="userid" name="stock" type="text" value=""></td>
            </tr>
            <tr>
                <td class="label">选择品牌:</td>
                <td>
                <select name="bid" id="sid">
                    <option value="default">--选择品牌--</option>
                    <?php
                        $sql="select * from category order by id";
                        $rows=mysql_query($sql);
                        while($row=mysql_fetch_assoc($rows)){
                            $sql2="select * from brand where cid={$row['id']}";
                            echo "<option disabled value='{$row['id']}'>{$row['cname']}</option>";
                            $rows2=mysql_query($sql2);
                            while($row2=mysql_fetch_assoc($rows2)){
                                echo "<option value='{$row2['id']}'>-{$row2['bname']}</option>";
                            }
                            //echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
            	<td  class="label">是否上架:</td>
				<td><input type="radio" name="cartup" value="0" checked />不上架  &nbsp;<input type="radio" name="cartup" value="1" />上架</td>
			</tr>
            <tr>
            <td class="label">商品详情:</td>
            <td>&nbsp;</td>
            </tr>
            
            <td colspan="2">
            <textarea id="editor_id" name="content" style="width:100%;height:300px;"></textarea>
            </td>
    </table>
    <div class="button-div">
        <input type="submit" value=" 确定 " class="button" >
        <input type="reset" value=" 重置 " class="button">
    </div>
</form> 
</div>
</div>
<?php include("../public/page_footer.php"); ?>