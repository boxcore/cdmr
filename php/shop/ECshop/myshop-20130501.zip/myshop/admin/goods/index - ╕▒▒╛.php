<?php  
include('../include/access1.php');

//加工搜索 和分页
$search_key="name"; //能用于搜索的字段
foreach($_GET as $key=>$val){
	if(!empty($val) && $key==$search_key){
		$arr[]="$key like '%$val%'";
		$url[]="$key=$val";
	}                 
}

if(is_array($arr)){
	$where="where ".join(" and ",$arr);
	$url=join("&",$url);
}

//修改产品上下架状态
if($_GET["state"]){
	switch($_GET["state"]){
		case "up":
		$state=1;
		break;
		case "down":
		$state=0;
		break;
	}
$sql="update goods set cartup={$state} where id={$_GET['id']}";
$rows=mysql_query($sql);
echo "<script>javascript:history.go(-1);</script>";
}	

//页面开始

//初始页面内容
$page_action=array("add.php","添加产品");
$page_here="产品列表";
$page_name="index.php";

include("../public/page_header.php"); 
?>

<!-- 商品搜索 -->
<?php include('../public/goods_search.php'); ?>

<!-- 商品列表 -->

<div class="list-div" id="listDiv">
  <table cellpadding="3" cellspacing="1">
    <tr>
      <th>编号</th>
      <th width="300">商品名称</th>
      <th>品牌[分类]</th>
      <th>图片</th>
      <th>价格</th>
      <th>库存</th>
      <th>添加时间</th>
      <th>上架</th>
      <th>操作</th>
    </tr>
    <?php
	$page=$_GET['page']?$_GET['page']:1;
                    $length=$_GET['length']?$_GET['length']:5;

                    $sql="select count(*) from goods $where";
                    $rows=mysql_query($sql);
                    $row=mysql_fetch_row($rows);
                    $tot=$row[0];
                    
                    $pagenum=ceil($tot/$length);
                    $offset=($page-1)*$length;
                        
                    $prev=$page-1;
                    if($page<=1){
                        $prev=1; 
                    }

                    $next=$page+1;
                    if($page>=$pagenum){
                        $next=$pagenum; 
                    }
				$sql="select * from goods {$where} order by id limit $offset,$length";
				$rows=mysql_query($sql);
				if(mysql_num_rows($rows)){
                while($row=mysql_fetch_assoc($rows)){
					echo "
						<tr>
                        <td align='center' width='30px'>{$row['id']}</td>
                        <td>{$row['name']}</td>
						<td>";
						;
						$sql_b="select * from brand where id={$row['bid']}";
						$row_b=mysql_fetch_assoc(mysql_query($sql_b));
						echo $row_b['bname'];
						$sql_c="select * from category where id={$row_b['cid']}";
						$row_c=mysql_fetch_assoc(mysql_query($sql_c));
						echo " 【{$row_c['cname']}】";
						
						echo "</td>
                        <td align='center'><a href='../../images/".substr($row['pic'],4)."' target='_blank'><img src='../../images/{$row['pic']}' height=60/></a></td>
                        <td>{$row['price']}</td>
                        <td >{$row['stock']}</td>
                        <td align='center'>".date('Y-m-d',$row['time'])."</td>";
					   
						switch($row['cartup']){
							case 0:
							echo "<td align='center'><a href='index.php?id={$row['id']}&state=up'><img src='../public/images/no.gif' /></a></td>";
							break;
							case 1:
							echo "<td align='center'><a href='index.php?id={$row['id']}&state=down'><img src='../public/images/yes.gif' /></a></td>";
							break;
						}
						echo "
						<td align='center'>
							<a href='../goods.php?id=' target='_blank' title=''><img src='../public/images/icon_view.gif' width='16' height='16' border='0' /></a>
							<a href='edit.php?id={$row['id']}' name='list_{$row['id']}' title='编辑'><img src='../public/images/icon_edit.gif' width='16' height='16' border='0' /></a>
							<a href='del.php?id={$row['id']}&delpic={$row['pic']}' title='删除'><img src='../public/images/no.gif' width='16' height='16' border='0' /></a></td>
					</tr>";
				}
			}else{
			echo "<tr><td class='no-records' colspan='9'>没有记录</td></tr>";
		} 
	?>
  </table>
  
  <!-- 分页 -->
  <table id="page-table" cellspacing="0">
    <tr>
      <td align="right" nowrap="true"><?php include("../public/page.php"); ?></td>
    </tr>
  </table>
</div>
<div style="height:20px"></div>
<?php include("../public/page_footer.php"); ?>
