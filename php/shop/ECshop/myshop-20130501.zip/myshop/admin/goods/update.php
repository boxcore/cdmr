<?php
include('../include/access1.php');
include("../include/func.php");
if($_FILES['pic']['error']===0){
    $picfile=upload("pic","../../images/");
	$pic=thumb($picfile,160,160);
	$pic_mid=thumb($picfile,350,350,"mid_");
    if($_POST['oldpic']){
		unlink("../../images/{$_POST['oldpic']}");
		unlink("../../images/".substr($_POST['oldpic'],4));
		@unlink("../../images/mid_".substr($_POST['oldpic'],4));
	}
}else{
    $pic=$_POST['oldpic'];
}
$name=$_POST['name'];
$price=$_POST['price'];
$stock=$_POST['stock'];
$bid=$_POST['bid'];
$cartup=$_POST['cartup'];
$content=$_POST['content'];

$sql="update goods set name='{$name}',pic='{$pic}',price='{$price}',stock='{$stock}',cartup='{$cartup}',bid='{$bid}',content='{$content}' where id={$_POST['id']}";
if(mysql_query($sql)){
    echo "<script>javascript:history.go(-2);</script>";
}
