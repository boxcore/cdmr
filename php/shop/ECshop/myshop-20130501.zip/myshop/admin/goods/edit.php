<?php
include('../include/access1.php');

$id=$_GET['id'];
$sql="select * from goods where id={$id}";
$rows=mysql_query($sql);
$row=mysql_fetch_assoc($rows);

//初始页面内容
$page_action=array("index.php","商品列表");
$page_here="编辑商品信息";
$page_name="edit.php";
include("../public/page_header.php"); 

?>
<!-- start goods form -->
<div class="tab-div">

<!-- tab bar -->
    <div id="tabbar-div">
      <p>
        <span class="tab-front" id="general-tab">通用信息</span>
      </p>
    </div>

<!-- tab body -->
<div id="tabbody-div">
<form enctype="multipart/form-data" action="update.php" method="post" name="theForm" >
<div class="button-div">
        <input type="submit" value=" 确定 " class="button" >
        <input type="reset" value=" 重置 " class="button">
    </div>
<!-- 通用信息 -->
    <table width="90%" id="general-table" align="center">
            <tr>
                <td class="label">商品名称:</td>
				<td><input id="userid" name="name" type="text" value="<?php echo $row['name'] ?>"></td>
            <tr>
			<tr>
				<td class="label">&nbsp;</td>
				<td><img id="imgid" class="img" src="../../images/<?php echo $row['pic'] ?>"></td>
			</tr>
            <tr>
                <td  class="label">商品图片:</td>
				<td><input id="userid" name="pic" type="file" value="<?php echo $row['pic']?>"></td>
            </tr>
            <tr>
                <td  class="label">商品单价:</td><td><input id="userid" name="price" type="text" value="<?php echo $row['price']?>"></td>
            </tr>
            <tr>
                <td  class="label">库存量:</td>
				<td><input id="userid" name="stock" type="text" value="<?php echo $row['stock']?>"></td>
            </tr>
            <tr>
                <td  class="label">选择品牌:</td>
                <td>
                <select name="bid" id="sid">
                    <option value="default">--选择品牌--</option>
                    <?php
                        $sql2="select * from category order by id";
                        $rows2=mysql_query($sql2);
                        while($row2=mysql_fetch_assoc($rows2)){
                            echo "<option disabled value='{$row2['id']}'>{$row2['cname']}</option>";
                            $sql3="select * from brand where cid={$row2['id']}";
                            $rows3=mysql_query($sql3);
                            while($row3=mysql_fetch_assoc($rows3)){
                                if($row3['id']==$row['bid']){
                                    echo "<option selected value='{$row3['id']}'>--{$row3['bname']}</option>";
                                }else{
                                    echo "<option value='{$row3['id']}'>--{$row3['bname']}</option>";
                                }
                            }
                            //echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
            	<td  class="label">是否上架:</td>
				<td><input type="radio" name="cartup" value="0" <?php if($row['cartup']==0){echo "checked";} ?> />不上架  &nbsp;<input type="radio" name="cartup" value="1" <?php if($row['cartup']){echo "checked";} ?> />上架</td>
			</tr>
            <tr>
            <td colspan="2">
            <textarea id="editor_id" name="content" style="width:100%;height:300px;"><?php echo $row['content'] ?></textarea>
            </td>
            </tr>

    </table>
    
<!-- 详情描述 -->

	<div class="button-div">
		<input type="hidden" name="oldpic" value="<?php echo $row['pic'] ?>">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
        <input type="submit" value=" 确定 " class="button" >
        <input type="reset" value=" 重置 " class="button">
    </div>
</form>

</div>
	
</div>
<!-- end goods form -->
<?php include("../public/page_footer.php"); ?>

