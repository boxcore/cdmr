<?php
include('../include/access1.php');
include("../include/func.php");

$name=$_POST['name'];
$price=$_POST['price'];
$stock=$_POST['stock'];
$bid=$_POST['bid'];
$time=time();
if($_FILES['pic']['error']===0){
$picfile=upload("pic","../../images/");
$pic=thumb($picfile,160,160);
$pic_mid=thumb($picfile,350,350,"mid_");

}
$sql="insert into goods(name,pic,price,stock,bid,time) values('{$name}','{$pic}','{$price}','{$stock}','{$bid}','{$time}')";

if(mysql_query($sql)){
	header("location:index.php");
    /*echo "<script>javascript:history.go(-2);</script>";*/
}

