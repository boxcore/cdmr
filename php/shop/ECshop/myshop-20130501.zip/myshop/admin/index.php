<?php include("include/access.php") ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <title>管理首页</title>
    <style type="text/css">
    </style>
</head>





<frameset rows="76,*" framespacing="0" border="0">
  <frame src="public/top.php" id="header-frame" name="header-frame" frameborder="no" scrolling="no">
  <frameset cols="180, 10, *" framespacing="0" border="0" id="frame-body">
    <frame src="public/menu.php" id="menu-frame" name="menu-frame" frameborder="no" scrolling="yes">
    <frame src="public/drag.php" id="drag-frame" name="drag-frame" frameborder="no" scrolling="no">
    <frame src="public/main.php" id="main-frame" name="main-frame" frameborder="no" scrolling="yes">
  </frameset>
</frameset><noframes></noframes>



</html>

