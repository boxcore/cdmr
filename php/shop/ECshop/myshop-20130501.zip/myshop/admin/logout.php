<?php
//登出清空session和cookie
session_start();
$_SESSION=array();
setcookie("PHPSSID","",time()-1,"");
session_destroy();
header("location:index.php");
?>
