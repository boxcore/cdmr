<?php
session_start(); 
if($_SESSION['padmin']!=1){
	header("location:../login.php");
}
include("../../include/init.php");
header("content-type:text/html;charset=utf8");


    $id=$_POST['id'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $admin=$_POST['admin'];
    $addr=$_POST['addr'];
    $tel=$_POST['tel'];
	$mail=$_POST['mail'];
	$realname=$_POST['realname'];
	$question=$_POST['question'];
	$answer=$_POST['answer'];
    $sql="update user set username='{$username}',password='{$password}',admin='{$admin}',addr='{$addr}',tel='{$tel}',mail='{$mail}',realname='{$realname}',question='{$question}',answer='{$answer}' where id={$id}";
	
	
    if(mysql_query($sql)){
        header("location:index.php"); 
	}
