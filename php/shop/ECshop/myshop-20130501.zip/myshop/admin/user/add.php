<?php
/**
 * 添加会员账号
 * 
*/

include('../include/access1.php');

//初始页面内容
$page_action=array("index.php","会员列表");
$page_here="添加会员账号";
$page_name="add.php";
include("../public/page_header.php");
?>
<div class="main-div">
        <form id="fid" action="insert.php" method="post">
<table width="100%" >
<tr>
<td class="label">用户名:</td>
<td><input id="username" name="username" type="text" value="" /></td>
</tr>

<tr>
<td class="label">密码: </td>
<td><input id="password" name="password" type="password" value=""></td>
</tr>

<tr>
<td class="label">是否管理员：</td>
<td><input type="radio" name="admin" value="0" checked />普通会员 &nbsp; <input type="radio" name="admin" value="1" />管理员 &nbsp;</td>
</tr>

<tr>
<td class="label">地址:&nbsp;&nbsp; </td>
<td><input id="addr" name="addr" type="text" value=""></td>
<tr>

<tr>
<td class="label">电话: </td>
<td><input id="tel" name="tel" type="text" value=""></td>
</tr>

<tr>
<td class="label">邮箱: </td>
<td><input id="mail" name="mail" type="text" value=""></td>
</tr>

<tr>
<td class="label">中文全名: </td>
<td><input id="realname" name="realname" type="text" value=""></td>
</tr>

<tr>
<td class="label">密保问题: </td>
<td><input id="question" name="question" type="text" value=""></td>
</tr>


<tr>
<td class="label">密保答案: </td>
<td><input id="answer" name="answer" type="text" value=""></td>
</tr>
</table>
<div class="button-div">
	<input name="sub" type="submit" value="点击修改">&nbsp;
    <input name="reset" type="reset" value="重置" />
</div>
</form>
</div>
<?php include("../public/page_footer.php"); ?>