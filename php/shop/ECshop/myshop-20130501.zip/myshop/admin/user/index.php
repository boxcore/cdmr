<?php
/**
 * 会员列表
 * 
*/

include('../include/access1.php');

//加工搜索 和分页
$search_key="username"; //能用于搜索的字段
foreach($_GET as $key=>$val){
	if(!empty($val) && $key==$search_key){
		$arr[]="$key like '%$val%'";
		$url[]="$key=$val";
	}                 
}

if(is_array($arr)){
	$where="where ".join(" and ",$arr);
	$url=join("&",$url);
}

//初始页面内容
$page_action=array("add.php","添加会员");
$page_here="会员";
$page_name="index.php";
include("../public/page_header.php"); 
?>
<!-- 用户搜索 -->
<?php include('../public/page_search.php'); ?>

<form method="POST" action="" name="listForm" onsubmit="return confirm_bath()">
<!-- start users list -->
<div class="list-div" id="listDiv">
<!--用户列表部分-->
<table cellpadding="3" cellspacing="1">

            <tr>
                <th width="30">ID</th>
                <th>用户名</th>
                <th width="60">权限</th>
                <th>地址</th>
                <th>电话</th>
                <th>电子邮箱</th>
                <th>中文名</th>
                <th>用户管理</th>
            </tr>
            <?php
			$page=$_GET['page']?$_GET['page']:1;
                    $length=$_GET['length']?$_GET['length']:5;

                    $sql="select count(*) from user {$where}";
                    $rows=mysql_query($sql);
                    $row=mysql_fetch_row($rows);
                    $tot=$row[0];
                    
                    $pagenum=ceil($tot/$length);
                    $offset=($page-1)*$length;
                        
                    $prev=$page-1;
                    if($page<=1){
                        $prev=1; 
                    }

                    $next=$page+1;
                    if($page>=$pagenum){
                        $next=$pagenum; 
                    }
                $sql="select * from user {$where} order by id limit $offset,$length";
                $rows=mysql_query($sql);
                while($row=mysql_fetch_assoc($rows)){
                    echo "<tr>
                        <td align='center'>{$row['id']}</td>
                        <td>{$row['username']}</td>";
						
						switch ($row["admin"]){
							case 0:
							echo "<td>普通用户</td>";
							break;
							case 1:
							echo "<td>管理员</td>";
							break;
						}
						
                  
						
						echo "
                        <td>{$row['addr']}</td>
                        <td>{$row['tel']}</td>
                        <td>{$row['mail']}</td>
						<td>{$row['realname']}</td>
                        <td align='center'><a href='edit.php?id={$row['id']}' title='编辑'><img src='../public/images/icon_edit.gif' width='16' height='16' border='0'></a>&nbsp;<a href='del.php?id={$row['id']}' title='删除'><img src='../public/images/no.gif' width='16' height='16' border='0'></a></td>
                    </tr>";
                  
                }
            ?>
        </table>
      <!-- 分页 -->
  <table id="page-table" cellspacing="0">
    <tr>
      <td align="right" nowrap="true"><?php include("../public/page.php"); ?></td>
    </tr>
  </table>
    </div>
</form>
<?php include("../public/page_footer.php"); ?>

