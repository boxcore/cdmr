<?php
/**
 * 编辑会员账号
 * 
*/

include('../include/access1.php');

//查用户表
$id=$_GET['id'];
$sql="select * from user where id={$id}";
$rows=mysql_query($sql);
$row=mysql_fetch_assoc($rows);

//初始页面内容
$page_action=array("index.php","会员列表");
$page_here="编辑会员账号";
$page_name="edit.php";
include("../public/page_header.php"); 
?>
<div class="main-div">
<form id="fid" action="update.php" method="post">
<table width="100%" >
<tr>
<td class="label">用户名:</td>
<td><input id="username" name="username" type="text" value="<?php echo $row["username"] ?>" /></td>
</tr>
<tr>
<td class="label">密码:</td>
<td><input id="password" name="password" type="password" value="<?php echo $row["password"] ?>"></td>
</tr>
<tr>
<td class="label">是否管理员：</td>
<td><input type="radio" name="admin" value="0" <?php if($row["admin"]==0){echo "checked";} ?> />普通会员 &nbsp; <input type="radio" name="admin" value="1" <?php if($row["admin"]==1){echo "checked";} ?> />管理员 &nbsp;</td>
</tr>
<tr>
<td class="label">地址:&nbsp;&nbsp; </td>
<td><input id="addr" name="addr" type="text" value="<?php echo $row["addr"] ?>"></td>
</tr>
<tr>
<td class="label">电话: </td>
<td><input id="tel" name="tel" type="text" value="<?php  echo $row["tel"]?>"></td>
</tr>
<tr>
<td class="label">邮箱: </td>
<td><input id="mail" name="mail" type="text" value="<?php  echo $row["mail"]?>"></td>
</tr>
<tr>
<td class="label">中文全名: </td>
<td><input id="realname" name="realname" type="text" value="<?php  echo $row["realname"]?>"></td>
</tr>
<tr>
<td class="label">密保问题: </td>
<td><input id="question" name="question" type="text" value="<?php  echo $row["question"]?>"></td>
</tr>
<tr>
<td class="label">密保答案: </td>
<td><input id="answer" name="answer" type="text" value="<?php  echo $row["answer"]?>"></td>
</tr>
</table>
<div class="button-div">
	<input id="input" type="hidden" name="id" value="<?php echo $row["id"]?>">
	<input name="sub" type="submit" value="点击修改">
    <input name="reset" type="reset" value="重置" />
</div>
</form>
</div>
<?php include("../public/page_footer.php"); ?>
