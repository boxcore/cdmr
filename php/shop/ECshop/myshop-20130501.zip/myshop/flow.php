<?php
include("include/access.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf8" />
		<title>reg</title>
		<link href="themes/style.css" type="text/css" rel="stylesheet" />
        <link href="themes/css/flow.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
<?php
include("themes/page_header.php"); 
$_GET["act"]?$_GET["act"]:($_GET["act"]="mycart");

/* 登陆页面 */
if($_GET["act"]=="mycart"){
	if($_SESSION["login"]!=1){
		echo "<script>alert('未登陆，请按确定去登陆页面！');</script>";
		echo "<script>location='user.php?act=login';</script>";
	}
	include("themes/flow_mycart.php");
}

//添加到购物车
elseif($_GET["act"]=="add"){

/* 购物车模块：计算购物车和总价
 * @param  $_SESSION["shops"]=key(pid)=>{0=>pid,1=>名称,2=>图片,3=>单价,4=>库存,5=>产品的添加时间,6=>上下架情况,7=>品牌id,num=>数目}
 * 说明：根据提交过来的产品id$_SESSION["shops"]["$id"]中
 */	
    $id=$_GET['id'];
	$sql="select goods.id,goods.name,goods.pic,goods.price,goods.stock from goods where id={$id}";
    $rows=mysql_query($sql);
    $row=mysql_fetch_assoc($rows);
    if($_SESSION["shops"]["$id"]){
        $_SESSION["shops"]["$id"]["num"]++;
    }else{
        $_SESSION["shops"]["$id"]=$row;
        $_SESSION["shops"]["$id"]["num"]=1;
    }
    echo "<script>location='flow.php?act=mycart';</script>";
}

//购物车中心
elseif($_GET["act"]=="center"){
	include("themes/flow_center.php");
}

//结算时展示的清单
elseif($_GET["act"]=="list"){
	include("themes/flow_list.php");
}

//生成订单
elseif($_GET["act"]=="insert"){
$uid=$_SESSION['user_id'];
$sn=time().mt_rand();
$info=urlencode(json_encode((object)$_SESSION['shops']));
$time=time();
$amount=$_SESSION["amount"];
foreach($_SESSION["shops"] as $key=>$goods){
	$sql_st="select * from goods where id={$goods['id']}";
	$row_st=mysql_fetch_assoc(mysql_query($sql_st));
	$stock=$row_st["stock"]-$goods["num"];
	
	
	$sql_st2="update goods set stock={$stock} where id={$goods['id']}";
	$row=mysql_query($sql_st2);
}
$sql="insert into ordertab(uid,sn,info,time,amount) values($uid,'$sn','$info',$time,$amount)";
if(mysql_query($sql)){
	unset($_SESSION['shops']); //把保存为订单的产品清单清空
	unset($_SESSION['amount']); //把订单的总价清空
    echo "<script>location='user_area.php?act=order';</script>";
}
}
?>



		<?php include("themes/page_footer.php"); ?>
	</body>
</html>



