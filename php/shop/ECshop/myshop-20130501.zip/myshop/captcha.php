<?php
	session_start();
    include("include/init.php");
    include("include/func.php");
	code()
?>