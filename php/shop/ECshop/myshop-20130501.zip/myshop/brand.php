<?php
session_start();
include("include/access.php");
include("themes/common/theme.func.php");
//获取分类页面的id 同时赋值给 $id
//$bid=$_GET['id'];
$brand_id=$_GET['id'];

//查询出品牌名字并赋值给$brand_name 
$sql_b="select * from brand where id={$brand_id}";
$row_b=mysql_fetch_assoc(mysql_query($sql_b));
$brand_name=$row_b['bname'];
$brand_cid=$row_b['cid'];

//取品牌所属分类名称 ** $row_c的值将被ur_here 使用
$sql_c="select * from category where id=$brand_cid";
$row_c=mysql_fetch_assoc(mysql_query($sql_c));
$cat_name=$row_c['cname'];
$cat_id=$row_c['id'];

//给与页面初始变量

//分类页地址，分页时调用
$page_name="brand.php";
$base_uri="brand.php?id=$brand_id";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf8" />
<title>brand</title>
<link href="themes/style.css" type="text/css" rel="stylesheet" />
<link href="themes/css/page.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php include("themes/page_header.php"); ?>
<div class="clearfix clr blank"></div>

<!-- 当前的分类导航 -->
<div class="w mt10">
  <div class="cat-bread">
    <?php include("themes/ur_here.php"); ?>
  </div>
</div>
<div id="main" class="w mt10">
<div class="right">

<!-- 分类所有产品 -->
<?php 
//include("themes/lib/cat_goods_list.php");
include("themes/search_list.php");
 ?>
<div class="clr"></div>
<!-- 分页 -->
<?php include("themes/list_page.php"); ?>

<div class="clr"></div>
<?php
		//分类下随机品牌的产品
		include("themes/brand_shuffle.php"); //用于测试的模版数据
	?>
</div>
<div class="left"> 
  <!-- 分类树 -->
  <?php include("themes/cat_tree.php"); ?>
</div>

<!-- 文章中心 -->
</div>
<!-- -->
<div class='clr'></div>
<?php include("themes/page_footer.php"); ?>
</body>
</html>
