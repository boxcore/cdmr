<?php
session_start();
include("include/access.php");
include("themes/common/theme.func.php");
//获取分类页面的id 同时赋值给 $id
//$cid=$_GET['id'];
$cat_id=$_GET['id'];

//查询出品牌名字并赋值给$cat_name 
$sql_c="select * from category where id={$cat_id}";
$row_c=mysql_fetch_assoc(mysql_query($sql_c));
$cat_name=$row_c['cname'];

//给与页面初始变量

//分类页地址，分页时调用
$page_name="category.php";
$base_uri="category.php?id=$cat_id";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf8" />
<title>category</title>
<link href="themes/style.css" type="text/css" rel="stylesheet" />
<link href="themes/css/page.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php include("themes/page_header.php"); ?>
<div class="clearfix clr blank"></div>

<!-- 当前的分类导航 -->
<div class="w mt10">
  <div class="cat-bread">
    <h1><a><?php echo $cat_name; ?>&gt;&gt;</a></h1>
    <span>
    <?php
				$sql_pb="select * from brand where cid={$cat_id}";
				$rows_pb=mysql_query($sql_pb);
				while($row_pb=mysql_fetch_assoc($rows_pb)){
					echo "&nbsp;&nbsp;<a href='brand.php?id={$row_pb['id']}'>{$row_pb['bname']}</a>&nbsp;&nbsp;|";
				}
			?>
    </span> </div>
</div>
<div id="main" class="w mt10">
  <div class="right"> 
    
    <!-- 分类所有产品 -->
    <?php 
	//include("themes/lib/cat_goods_list.php");
	include("themes/search_list.php");
	?>
    <div class="clr"></div>
    <!-- 分页 -->
    <?php include("themes/list_page.php"); ?>
    <!-- 分类下品牌产品列表 -->
    <?php
		//分类下随机品牌的产品
		include("themes/brand_shuffle.php"); //用于测试的模版数据
	?>
  </div>
  <div class="left"> 
    <!-- 分类树 -->
    <?php include("themes/cat_tree.php"); ?>
  </div>
  
  <!-- 文章中心 --> 
</div>
<!-- -->
<div class='clr'></div>
<?php include("themes/page_footer.php"); ?>
</body>
</html>
