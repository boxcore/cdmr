<?php
$lang['L_LOG_DELETE']="Raporu sil";
$lang['L_LOGFILEFORMAT']="Rapor dosyasının biçimi";
$lang['L_LOGFILENOTWRITABLE']="Rapor dosyasına yazılamıyor!";
$lang['L_NOREVERSE']="Eski kayıtlar önce";
$lang['L_REVERSE']="Yeni kayıtlar önce";


?>