<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Jusqu'à présent <b>%d</b> tables ont été créés.";
$lang['L_FILE_MISSING']="le fichier n'a pas été trouvé";
$lang['L_RESTORE_DB']="Base de données '<b>%s</b>' sur le serveur '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tables ont été créés.";
$lang['L_RESTORE_RUN1']="<br>Jusqu'à présent <b>%s</b> de <b>%s</b> enregistrements ont été enregistrés.";
$lang['L_RESTORE_RUN2']="<br>En ce moment la table '<b>%s</b>' avec ces enregistrements est en cours de traitement.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> enregistrements ont été enregistrés.";
$lang['L_RESTORE_TABLES_COMPLETED']="Jusqu'à présent <b>%d</b> de <b>%d</b> tables ont été créés.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Toutes nos félicitations.</b><br><br>La base de données a été restaurée complètement.<br>Tous les fichiers de la copie de sauvegarde ont été enregistrés avec succès dans la base de données.<br><br>Restauration terminée. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Erreur:<br>Choix de la base de données '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' échoué!";
$lang['L_FILE_OPEN_ERROR']="Erreur: Le fichier n'a pas pu être ouvert.";
$lang['L_PROGRESS_OVER_ALL']="Progression totale";
$lang['L_BACK_TO_OVERVIEW']="Aperçu général des bases de données";
$lang['L_RESTORE_RUN0']="<br>Jusqu'à présent <b>%s</b> enregistrements ont été enregistrés avec succès.";
$lang['L_UNKNOWN_SQLCOMMAND']="Commande SQL inconnue";
$lang['L_NOTICES']="Notices";


?>