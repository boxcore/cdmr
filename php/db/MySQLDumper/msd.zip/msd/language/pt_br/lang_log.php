<?php
$lang['L_LOG_DELETE']="excluir log";
$lang['L_LOGFILEFORMAT']="Formato do arquivo de log";
$lang['L_LOGFILENOTWRITABLE']="Não pude escrever no arquiuvo de log !";
$lang['L_NOREVERSE']="Entradas mais antigas primeiro";
$lang['L_REVERSE']="Últimas entradas primeiro";


?>