<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Hittills har <b>%d</b> av <b>%d</b> tabeller skapats.";
$lang['L_FILE_MISSING']="kunde ej hitta filen";
$lang['L_RESTORE_DB']="Databas '<b>%s</b>' på server '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tabeller har skapats.";
$lang['L_RESTORE_RUN1']="<br>Hittills har <b>%s</b> av <b>%s</b> dataposter överförts.";
$lang['L_RESTORE_RUN2']="<br>För närvarande analyseras datan i tabell '<b>%s</b>'.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> dataposter har överförts.";
$lang['L_RESTORE_TABLES_COMPLETED']="Hittills har <b>%d</b> av <b>%d</b> tabeller skapats.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Grattis!</b><br><br>Databasen har återställts komplett.<br>All data ur backupfilen har överförts till databasen.<br><br>Allt är färdigt. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Fel:<br> val av databasen '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' misslyckades!";
$lang['L_FILE_OPEN_ERROR']="Fel: filen kunde ej öppnas.";
$lang['L_PROGRESS_OVER_ALL']="Framsteg totalt";
$lang['L_BACK_TO_OVERVIEW']="Databasöversikt";
$lang['L_RESTORE_RUN0']="<br>Hittills har <b>%s</b> dataposter överförts.";
$lang['L_UNKNOWN_SQLCOMMAND']="Okänt SQL-kommando:";
$lang['L_NOTICES']="Hänvisningar";


?>