<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Foreløbigt er der oprettet <b>%d</b> tabeller.";
$lang['L_FILE_MISSING']="kunne ikke finde fil";
$lang['L_RESTORE_DB']="Database '<b>%s</b>' på '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tabeller oprettet.";
$lang['L_RESTORE_RUN1']="<br>Foreløbigt er der korrekt tilføjet  <b>%s</b> af <b>%s</b> poster.";
$lang['L_RESTORE_RUN2']="<br>Tabellen '<b>%s</b>' er under genetablering.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> poster indsat.";
$lang['L_RESTORE_TABLES_COMPLETED']="Foreløbigt er der oprettet <b>%d</b> af <b>%d</b> tabeller.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Tillykke.</b><br><br>Genetableringen af databasen er færdig.<br>Alle data fra Backupfilen er blevet genetableret.<br><br>Processen er færdig. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Fejl:<br>Valg af database <b>";
$lang['L_DB_SELECT_ERROR2']="</b> fejlede!";
$lang['L_FILE_OPEN_ERROR']="Fejl: kunne ikke åbne fil.";
$lang['L_PROGRESS_OVER_ALL']="Samlede fremskridt";
$lang['L_BACK_TO_OVERVIEW']="Database-oversigt";
$lang['L_RESTORE_RUN0']="<br>foreløbigt er der korrekt tilføjet <b>%s</b> poster.";
$lang['L_UNKNOWN_SQLCOMMAND']="ukendt SQL-kommando";
$lang['L_NOTICES']="Bemærkninger";


?>