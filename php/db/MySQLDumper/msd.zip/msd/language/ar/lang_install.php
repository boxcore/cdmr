<?php
$lang['L_INSTALLFINISHED']="<br>تم اكتمال التركيب  --> <a href=\"index.php\">ابدأ MySQLDumper</a><br>";
$lang['L_INSTALL_TOMENU']="عوده الى القائمة الرئيسة";
$lang['L_INSTALLMENU']="القائمة الرئيسة";
$lang['L_STEP']="خطوة ";
$lang['L_INSTALL']="التركيب";
$lang['L_UNINSTALL']="مسح";
$lang['L_TOOLS']="الادوات";
$lang['L_EDITCONF']="تعديل الدليل";
$lang['L_OSWEITER']="مواصلة بدون حفظ";
$lang['L_ERRORMAN']="<strong>خطأ اثناء عملية حفظ البيانات!</strong><br>الرجاء تعديل الملف ";
$lang['L_MANUELL']="يدوي";
$lang['L_CREATEDIRS']="انشاء الادلة";
$lang['L_INSTALL_CONTINUE']="استمر بعملية التركيب";
$lang['L_CONNECTTOMYSQL']="ربط الى MySQL ";
$lang['L_DBPARAMETER']="قاعدة البيانات Parameters";
$lang['L_CONFIGNOTWRITABLE']="لا يمكن الكتابة للملف \"config.php\".
الرجاء استخدام برامج بروتوكول نقل الملفات الخاصة بك واعط الملف التصريح0777.";
$lang['L_DBCONNECTION']="الاتصال بقاعدة البيانات";
$lang['L_CONNECTIONERROR']="خطأ غير قادر على الربط.";
$lang['L_CONNECTION_OK']="تم تأسيس الاتصال بقاعدة البيانات.";
$lang['L_SAVEANDCONTINUE']="حفظ ومتابعة التركيب";
$lang['L_CONFBASIC']="اساسي Parameter";
$lang['L_INSTALL_STEP2FINISHED']="تم الوصول الى قاعدة البيانات بنجاح.";
$lang['L_INSTALL_STEP2_1']="متابعة التركيب بالإعدادات الافتراضية";
$lang['L_LASTSTEP']="انتهى التركيب";
$lang['L_FTPMODE']="انشاء ادلة ضرورية في النمط الآمن";
$lang['L_IDOMANUAL']="انشاء الدليل الخاص بي";
$lang['L_DOFROM']="بداية من";
$lang['L_FTPMODE2']="تهيئة  مع بروتوكول نقل الملفات FTP:";
$lang['L_CONNECT']="ربط";
$lang['L_DIRS_CREATED']="انشاء الادلة بشكل صحيح.";
$lang['L_CONNECT_TO']="ربط الى";
$lang['L_CHANGEDIR']="تغيير مياشر";
$lang['L_CHANGEDIRERROR']=" لا يمكن التغيير مباشرة ";
$lang['L_FTP_OK']="FTPيفضل برتكول ";
$lang['L_CREATEDIRS2']="انشاء الادلة";
$lang['L_FTP_NOTCONNECTED']="FTP لم يتم انشاء برتكول نقل الملفات!";
$lang['L_CONNWITH']="اتصال مع";
$lang['L_ASUSER']="اسم المستخدم";
$lang['L_NOTPOSSIBLE']="غير ممكن";
$lang['L_DIRCR1']="انشاء في دليل العمل";
$lang['L_DIRCR2']="انشاء في دليل الاسناد";
$lang['L_DIRCR4']="انشاء في السجل";
$lang['L_DIRCR5']="انشاء في  configurationdir";
$lang['L_INDIR']="الآن في ";
$lang['L_CHECK_DIRS']="فحص الادلة";
$lang['L_DISABLEDFUNCTIONS']="الوظائف المعطلة";
$lang['L_NOFTPPOSSIBLE']="لا يجد لديك وظائف بروتوكول نقل الملفات FTP  !";
$lang['L_NOGZPOSSIBLE']="لا يوجد لديك وظائف ضغط الملفات  !";
$lang['L_UI1']="جميع أدلة العمل التي يمكن أن تحتوي النسخ الاحتياطي سيتم حذفها.";
$lang['L_UI2']="هل انت موافق على عمل ذلك?";
$lang['L_UI3']="لا, الغاء العملية";
$lang['L_UI4']="نعم ، من فضلك تابع";
$lang['L_UI5']="حذف ادلة العمل";
$lang['L_UI6']="تم حذف الجميع بنجاح.";
$lang['L_UI7']="رجاء احذف الدليل من المخطوطه";
$lang['L_UI8']="المستوى الاول الاعلى";
$lang['L_UI9']="حدث خطأ ، لم يكن من الممكن الحذف</p>خطأ بالدليل";
$lang['L_IMPORT']="استيراد الوظائف";
$lang['L_IMPORT3']="تحميل القوائم ...";
$lang['L_IMPORT4']="تم حفظ القوائم.";
$lang['L_IMPORT5']="ابدأ MySQLDumper";
$lang['L_IMPORT6']="تركيب القائمة";
$lang['L_IMPORT7']="ارسال القوائم";
$lang['L_IMPORT8']="عودة الى الرفع";
$lang['L_IMPORT9']="هذا ليس دليل اسناد !";
$lang['L_IMPORT10']="تم رفع القوائم بنجاح ...";
$lang['L_IMPORT11']="<strong>خطا: </strong>كانت هناك مشكلة في الكتابة الى sql_statements";
$lang['L_IMPORT12']="<strong>خطأ: </strong>كانت هناك مشكلة في الكتابة الى config.php";
$lang['L_INSTALL_HELP_PORT']="(empty = Default Port)";
$lang['L_INSTALL_HELP_SOCKET']="(empty = Default Socket)";
$lang['L_TRYAGAIN']="حاول مرة اخرى";
$lang['L_SOCKET']="توصيل";
$lang['L_PORT']="منفذ";
$lang['L_FOUND_DB']="العثور على قاعدة بيانات";
$lang['L_FM_FILEUPLOAD']="رفع ملف";
$lang['L_PASS']="كلمة المرور";
$lang['L_NO_DB_FOUND_INFO']="تم الاتصال بقاعدة البيانات بنجاح.<br>
تم قبول بيانات المستخدم الخصة بك لـ MySQL-Server.<br>
لم يستطيع العثور على اية قاعدة بيانات.<br>
البحث التلقائي لا يمكن من قبل الخادم.<br>
انت يجب أن تدخل اسم قاعدة البيانات يدويا بعد الانتهاء من التركيب.
اضغط هنا \"configuration\" \"Connection Parameter - display\" وتدخل اسم قاعدة البيانات هناك.

";
$lang['L_SAFEMODEDESC']="السبب PHP يعمل في الوضع الآمن فأنت تحتاج لإنشاء الادلة التالية يدويا بأستخدام برامج نقل الملفات  FTP-Programms:


";
$lang['L_ENTER_DB_INFO']="First click the button \"Connect to MySQL\". Only if no database could be detected you need to provide a database name here.";


?>